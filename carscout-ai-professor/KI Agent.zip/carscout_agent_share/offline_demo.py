"""Kostenlose Demonstration mit fest vorgegebenen, simulierten Modellantworten."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace

from agent import display_result, run_agent
from agent_tools import LocalTools
from create_test_database import create_database


def tool_call(name, args, call_id):
    return {"type": "function_call", "name": name, "arguments": json.dumps(args), "call_id": call_id}


class DemoResponses:
    def __init__(self):
        self.steps = iter([
            [tool_call("search_vehicles", {"brand": "BMW", "max_price": None, "max_mileage": None}, "1")],
            [tool_call("get_vehicle_details", {"listing_id": "SYN-004"}, "2")],
            [tool_call("save_analysis", {"listing_id": "SYN-004", "summary": "Motorwarnleuchte vor einem Einkauf fachlich prüfen", "facts": ["Inseratsangabe: Motorwarnleuchte leuchtet"], "risks": ["Hinweis: Ursache und Umfang eines möglichen Defekts unbekannt"], "uncertainties": ["Offene Frage: Welche Diagnose und Reparaturkosten fallen an?"], "recommendation": "zurueckstellen"}, "3")], []])

    def create(self, **kwargs):
        return SimpleNamespace(output=next(self.steps), status="completed", output_text="")


def main():
    print("OFFLINE-DEMO: fest vorgegebene simulierte Modellantworten; kein echtes LLM.")
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder) / "demo.sqlite3"
        with redirect_stdout(io.StringIO()):
            create_database(path)
        result = run_agent(SimpleNamespace(responses=DemoResponses()), "simulation", "Finde BMW und prüfe Risiken", LocalTools(path))
        display_result(result)
    print("Demo beendet: temporäre Datenbank entfernt, Projekt-Datenbank unverändert.")


if __name__ == "__main__":
    main()
