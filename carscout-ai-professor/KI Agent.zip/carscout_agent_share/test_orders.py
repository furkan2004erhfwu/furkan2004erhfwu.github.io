"""Mehrschritt-Aufträge ohne API-Aufrufe und ohne produktive Datenbank."""
from contextlib import closing, redirect_stdout
import io
import json
from pathlib import Path
import sqlite3
import tempfile
from types import SimpleNamespace
import unittest

from agent import run_agent
from agent_tools import LocalTools
from create_test_database import create_database, ROOT
from orders import Orders
from test_agent import FakeResponses, call


class OrderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'data.sqlite3'
        with redirect_stdout(io.StringIO()):
            create_database(self.path)
        self.tools = LocalTools(self.path)
        self.analysis = {"listing_id": "SYN-001", "summary": "Fahrzeug und Servicehistorie sorgfältig prüfen", "facts": ["Inseratsangabe: Wartungen dokumentiert"], "risks": ["Hinweis: Unterlagen sind nicht unabhängig geprüft"], "uncertainties": ["Offene Frage: Sind alle Belege vorhanden?"], "recommendation": "weiter_pruefen"}

    def fake(self, seq):
        responses = FakeResponses(seq)
        return SimpleNamespace(responses=responses)

    def resume(self, client, result, answer, **kwargs):
        return run_agent(client, 'fake', '', tools=LocalTools(self.path), resume_order_id=result['order_id'], answer=answer, **kwargs)

    def test_question_before_analysis_resume_and_context(self):
        client = self.fake([[call('ask_clarification', {'category':'marke'}, 'q')], [call('get_vehicle_details', {'listing_id':'SYN-001'}, 'd')], [call('save_analysis', self.analysis, 's')], []])
        first = run_agent(client, 'fake', 'Finde einen Wagen', self.tools)
        self.assertEqual(first['status'], 'rueckfrage')
        order = Orders(self.path).read(first['order_id'])
        self.assertEqual(order['status'], 'wartet_auf_antwort')
        self.assertIn('marke', order['question'].lower())
        self.assertEqual(order['context']['saved'], [])
        done = self.resume(client, first, 'BMW')
        self.assertEqual(done['order_id'], first['order_id'])
        self.assertEqual(done['status'], 'fertig')
        received = client.responses.requests[1]['input']
        self.assertIn('Finde einen Wagen', json.dumps(received, ensure_ascii=False))
        self.assertEqual(received[-1], {'role':'user','content':'BMW'})
        with closing(sqlite3.connect(self.path)) as db:
            self.assertEqual(db.execute('SELECT status FROM orders WHERE id=?', (first['order_id'],)).fetchone()[0], 'abgeschlossen')
            self.assertEqual(db.execute('SELECT order_id,run_status FROM analyses').fetchone(), (first['order_id'], 'abgeschlossen'))

    def test_multiple_invalid_cancel_and_limits(self):
        client = self.fake([[call('ask_clarification', {'category':'preis'}, 'q1')], [call('ask_clarification', {'category':'marke'}, 'q2')], [call('ask_clarification', {'category':'auftrag'}, 'q3')]])
        first = run_agent(client, 'fake', 'Suche', self.tools, max_questions=2)
        for invalid in ('', 'abc', '-100'):
            self.assertEqual(self.resume(client, first, invalid)['status'], 'rueckfrage')
        self.assertEqual(len(client.responses.requests), 1)
        second = self.resume(client, first, '15000')
        self.assertEqual(second['status'], 'rueckfrage')
        limited = self.resume(client, second, 'BMW')
        self.assertEqual(limited['status'], 'limit')
        self.assertEqual(Orders(self.path).read(first['order_id'])['status'], 'unvollstaendig')
        cancel_client = self.fake([[call('ask_clarification', {'category':'marke'})]])
        waiting = run_agent(cancel_client, 'fake', 'Suche', LocalTools(self.path))
        cancelled = self.resume(cancel_client, waiting, '/abbrechen')
        self.assertEqual(cancelled['status'], 'abgebrochen')
        self.assertEqual(Orders(self.path).read(waiting['order_id'])['status'], 'abgebrochen')
        self.assertEqual(len(cancel_client.responses.requests), 1)

    def test_later_explicit_margin_for_same_car(self):
        prices = {'listing_id':'SYN-001','purchase_price':17900,'incidental_costs':350,'preparation_costs':750,'sale_price':21000}
        sequence = [[call('get_vehicle_details', {'listing_id':'SYN-001'}, 'd')], [call('ask_clarification', {'category':'margeneingaben'}, 'q')], [call('calculate_margin', {**prices,'assumptions':'Nutzerangaben'}, 'm')], [call('save_analysis', self.analysis, 's')], []]
        client = self.fake(sequence)
        first = run_agent(client, 'fake', 'Marge prüfen', self.tools, price_inputs={**prices, 'sale_price':None})
        invalid = self.resume(client, first, '20000', price_inputs={**prices, 'listing_id':'SYN-002'})
        self.assertEqual(invalid['status'], 'rueckfrage')
        missing = self.resume(client, first, 'Der Verkaufspreis ist 21000')
        self.assertEqual(missing['status'], 'rueckfrage')
        done = self.resume(client, first, 'Werte eingegeben', price_inputs=prices)
        self.assertEqual(done['status'], 'fertig')
        self.assertEqual(done['analyses'][0]['analysis']['margin']['amount'], 2000)

    def test_error_before_and_after_analysis_never_completed(self):
        for steps in ([], [[call('get_vehicle_details', {'listing_id':'SYN-001'}, 'd')], [call('save_analysis', self.analysis, 's')]]):
            result = run_agent(self.fake(steps), 'fake', 'Prüfe', LocalTools(self.path))
            self.assertEqual(result['status'], 'fehler')
            self.assertEqual(Orders(self.path).read(result['order_id'])['status'], 'unvollstaendig')
            with closing(sqlite3.connect(self.path)) as db:
                for row in db.execute('SELECT run_status FROM analyses WHERE order_id=?', (result['order_id'],)):
                    self.assertEqual(row[0], 'unvollstaendig')

    def test_interruption_before_and_after_analysis_stays_open(self):
        for before in (True, False):
            class Interrupted:
                def __init__(self, initial):
                    self.fake = FakeResponses(initial)
                def create(self, **kwargs):
                    try:
                        return self.fake.create(**kwargs)
                    except StopIteration:
                        raise KeyboardInterrupt
            steps = [] if before else [[call('get_vehicle_details', {'listing_id':'SYN-001'}, 'd')], [call('save_analysis', self.analysis, 's')]]
            with self.assertRaises(KeyboardInterrupt):
                run_agent(SimpleNamespace(responses=Interrupted(steps)), 'fake', 'Prüfe', LocalTools(self.path))
            with closing(sqlite3.connect(self.path)) as db:
                oid, status = db.execute('SELECT id,status FROM orders ORDER BY rowid DESC LIMIT 1').fetchone()
                self.assertEqual(status, 'in_bearbeitung')
                statuses = [r[0] for r in db.execute('SELECT run_status FROM analyses WHERE order_id=?', (oid,))]
                self.assertEqual(statuses, [] if before else ['vorlaeufig'])

    def test_old_migration_preserves_vehicle_and_legacy_status_unknown(self):
        old = Path(self.tmp.name) / 'old.sqlite3'
        with closing(sqlite3.connect(old)) as db:
            for name in ('001-initial.sql','002-synthetic-vehicles.sql','003-analysis-status.sql'):
                db.executescript((ROOT/'memory/migrations'/name).read_text(encoding='utf-8'))
            db.execute("INSERT INTO listings VALUES ('SYN-001','synthetisch','fiktiv','2026-01-01')")
            db.execute("INSERT INTO synthetic_vehicles VALUES ('SYN-001','BMW','Test',1,1,2020,'Ort','Radio',1)")
            db.execute("INSERT INTO analyses VALUES ('old','SYN-001','{}','2026-01-01','abgeschlossen')")
            db.commit()
        result = run_agent(self.fake([[call('ask_clarification', {'category':'marke'})]]), 'fake', 'Suche', LocalTools(old))
        with closing(sqlite3.connect(old)) as db:
            self.assertEqual(db.execute("SELECT order_id,run_status FROM analyses WHERE id='old'").fetchone(), (None,'unbekannt'))
            self.assertEqual(db.execute('SELECT count(*) FROM synthetic_vehicles').fetchone()[0],1)
            self.assertEqual(db.execute('SELECT status FROM orders WHERE id=?',(result['order_id'],)).fetchone()[0], 'wartet_auf_antwort')


if __name__ == '__main__':
    unittest.main(verbosity=2)
