"""Kostenlose Tests der Live-Testvorbereitung mit simulierten Modellantworten."""
from contextlib import closing, redirect_stdout
import io
from pathlib import Path
import sqlite3
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from agent import run_agent
from agent_tools import LocalTools
from create_test_database import create_database
from live_review import report_order
from live_test import CASES, main, verify_test_data
from test_agent import FakeResponses, call


class LivePreparationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'test.sqlite3'
        with redirect_stdout(io.StringIO()):
            create_database(self.path)

    def test_synthetic_database_check(self):
        verify_test_data(self.path)
        with closing(sqlite3.connect(self.path)) as db:
            with db:
                db.execute("UPDATE listings SET source_reference='extern' WHERE id='SYN-001'")
        with self.assertRaises(ValueError):
            verify_test_data(self.path)

    def test_tool_trace_and_python_margin(self):
        case = CASES['2']
        analysis = {'listing_id':'SYN-004','summary':'Warnleuchte vor dem Einkauf prüfen','facts':['Inseratsangabe Motorwarnleuchte leuchtet'], 'risks':['Hinweis auf möglichen Motorschaden'], 'uncertainties':['Offene Frage nach Reparaturkosten'], 'recommendation':'zurueckstellen'}
        prices = case['prices']
        steps = [[call('search_vehicles', {'brand':'BMW','max_price':None,'max_mileage':None}, 's')], [call('get_vehicle_details', {'listing_id':'SYN-004'}, 'd')], [call('calculate_margin', {**prices, 'assumptions':'Nutzerangabe'}, 'm')], [call('save_analysis', analysis, 'a')], []]
        result = run_agent(SimpleNamespace(responses=FakeResponses(steps)), 'fake', case['request'], LocalTools(self.path), price_inputs=prices)
        report = report_order(self.path, result['order_id'], case)
        self.assertTrue(report['checks']['ziel_fahrzeug_untersucht'])
        self.assertTrue(report['checks']['python_marge_2300_eur'])
        self.assertTrue(report['checks']['risikohinweis_automatisch_erkennbar'])
        self.assertEqual([e['tool'] for e in report['tool_events']], ['search_vehicles','get_vehicle_details','calculate_margin','save_analysis'])

    def test_decline_never_constructs_client(self):
        made = []
        fake = SimpleNamespace(OpenAI=lambda **kwargs: made.append(kwargs))
        with patch.dict('os.environ', {'OPENAI_API_KEY':'dummy','OPENAI_MODEL':'fake'}), patch.dict('sys.modules', {'openai':fake}), patch('builtins.input', side_effect=['1','nein']), redirect_stdout(io.StringIO()) as output:
            main()
        self.assertEqual(made, [])
        self.assertIn('keine API-Anfrage', output.getvalue())
        self.assertNotIn('dummy', output.getvalue())

    def test_waiting_question_is_recorded(self):
        fake = SimpleNamespace(responses=FakeResponses([[call('ask_clarification', {'category':'margeneingaben'}, 'q')]]))
        result = run_agent(fake, 'fake', CASES['3']['request'], LocalTools(self.path))
        report = report_order(self.path, result['order_id'], CASES['3'])
        self.assertEqual(report['order_status'], 'wartet_auf_antwort')
        self.assertTrue(report['checks']['rueckfrage_gestellt'])
        self.assertEqual(report['tool_events'][0]['category'], 'margeneingaben')


if __name__ == '__main__':
    unittest.main(verbosity=2)
