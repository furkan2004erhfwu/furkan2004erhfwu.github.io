# Phase 3B – Vorbereitung für einen kontrollierten Live-Test

**Stand: vorbereitet, noch kein echter API-Aufruf.** Die bisherigen Tests
verwenden simulierte Modellantworten. Sie beweisen nicht, dass die Anbindung mit
einem echten Modell oder einem bestimmten Konto funktioniert.

## Erwartete Testfälle

| Auswahl | Auftrag | Erwartung für die spätere Prüfung |
| --- | --- | --- |
| 1 | BMW bis 18.000 Euro und 140.000 km, Analyse von SYN-001 | Suche und Details; SYN-001 passt mit 17.900 Euro und 132.000 km. |
| 2 | BMW 530d SYN-004 mit Risikoanalyse und Testmarge | Inserat erwähnt Motorwarnleuchte und Leistungsverlust. Für die getrennt erfassten Testwerte 8.900 / 300 / 500 / 12.000 Euro ergibt Python 2.300 Euro. |
| 3 | SYN-018 mit fehlenden Angaben und Rückfrage | Eine Rückfrage vor der Analyse; im Inserat fehlen Angaben zu Vorbesitzern und Service. Falls nach Margen gefragt wird, nur selbst eingegebene Werte verwenden. |

Das Modell kann anders reagieren. Die automatischen Prüfungen markieren nur
Werkzeug- und einfache Textmerkmale; die inhaltliche Beurteilung bleibt bei
einem Menschen. Ein fehlendes Merkmal ist ein Prüfergebnis, kein automatisch
erklärter Fehler. Keine aktuellen Marktpreise sind verfügbar.

## Vorbereitung in PowerShell – noch keine API-Anfrage

1. Öffne PowerShell und gehe zum Projekt:

   ```powershell
   cd '<PROJECT_DIR>'
   ```

2. Erstelle einmalig eine eigene Python-Umgebung und installiere darin das
   offizielle OpenAI-Paket. Die Installation lädt Pakete aus dem Internet, ist
   aber kein OpenAI-Modellaufruf. Falls der Paketdownload nicht funktioniert,
   die Fehlermeldung ohne Schlüssel zur Prüfung weitergeben.

   ```powershell
   & '<CODEX_PYTHON>' -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements-agent.txt
   ```

3. Erstelle im OpenAI-Plattformkonto einen eigenen API-Schlüssel. Der Schlüssel
   ist vertraulich: nicht in den Chat, die Projektdateien oder ein ZIP schreiben.
   Die folgende Eingabe zeigt den Schlüssel beim Tippen nicht an und setzt ihn
   nur für das aktuelle PowerShell-Fenster:

   ```powershell
   $carScoutKey = Read-Host 'OpenAI-API-Schlüssel lokal eingeben' -AsSecureString
   $env:OPENAI_API_KEY = [System.Net.NetworkCredential]::new('', $carScoutKey).Password
   Remove-Variable carScoutKey
   $env:OPENAI_MODEL = 'gpt-5.4-mini'
   ```

   Das Modell ist ein Beispiel mit Function-Calling-Unterstützung. Ob das Konto
   Zugriff darauf und ausreichendes Guthaben hat, ist hier nicht geprüft. Preise
   und Modellverfügbarkeit bitte im eigenen Konto prüfen. Das Fenster offen lassen.

4. Offline-Tests ohne API-Aufruf starten:

   ```powershell
   .\.venv\Scripts\python.exe -m unittest -q
   ```

## Erst nach ausdrücklicher Freigabe: ein Live-Test

```powershell
.\.venv\Scripts\python.exe live_test.py
```

Wähle zunächst **1** für den ersten Fall. Das Programm zeigt den Auftrag und
fragt dann ausdrücklich nach `ja`. Jeder weitere Fall benötigt einen eigenen
Programmstart und eine eigene Bestätigung. Ein Test kann bis zu zehn
Modellantworten und acht Werkzeugaufrufe enthalten; dies ist keine feste
Kostenobergrenze. Das Programm kontrolliert die Testdaten und verwendet eine
temporäre Datenbankkopie. Beim dritten Fall können Rückfragen im selben Auftrag
beantwortet oder mit `/abbrechen` beendet werden.

Das Werkzeugprotokoll und der einfache Soll-Ist-Vergleich werden unter
`live_test_results` als JSON gespeichert; dieser Ordner ist von Git ausgenommen.
Die Ausgabe zeigt ausgewählte Werkzeuge und die tatsächliche Python-Marge.
Die inhaltliche Modellbewertung erscheint als ungeprüft im Terminal und ist
zusätzlich manuell zu kontrollieren. Die temporäre Datenbank wird am Ende
gelöscht. Bei vorzeitigem Abbruch kann das Protokoll unvollständig sein oder
fehlen. Der Schlüssel wird nicht absichtlich ins Protokoll aufgenommen.

Nach den Tests kann der Schlüssel aus dem aktuellen Fenster entfernt werden:

```powershell
Remove-Item Env:OPENAI_API_KEY
```

Die Trinity-Vorlage und die unabhängigen YAML- und JSON-Schema-Metaschema-
Prüfungen sind weiterhin offen. Die bestehenden Grenzen zu Kontakten, Käufen,
synthetischen Daten und menschlicher Prüfung gelten unverändert.
