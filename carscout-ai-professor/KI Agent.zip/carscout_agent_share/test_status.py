"""Status und Rückfragen mit simuliertem Modell und temporären Datenbanken."""
from contextlib import closing, redirect_stdout
import io
import json
from pathlib import Path
import sqlite3
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from agent import display_result, run_agent
from agent_tools import LocalTools, read_analysis_statuses
from create_test_database import create_database, ROOT
from test_agent import FakeResponses, call


class StatusTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "vehicles.sqlite3"
        with redirect_stdout(io.StringIO()):
            create_database(self.path)
        self.tools = LocalTools(self.path)
        self.analysis = {"listing_id": "SYN-001", "summary": "Fahrzeug anhand der Unterlagen prüfen", "facts": ["Inseratsangabe: Service ist dokumentiert"], "risks": ["Hinweis: Servicebelege müssen geprüft werden"], "uncertainties": ["Offene Frage: Sind sämtliche Belege vorhanden?"], "recommendation": "weiter_pruefen"}

    def client(self, outputs):
        return SimpleNamespace(responses=FakeResponses(outputs))

    def saved_status(self):
        with closing(sqlite3.connect(self.path)) as db:
            return db.execute("SELECT run_status FROM analyses ORDER BY rowid").fetchall()

    def save_steps(self):
        return [[call("get_vehicle_details", {"listing_id": "SYN-001"}, "1")], [call("save_analysis", self.analysis, "2")]]

    def test_safe_clarification_and_no_analysis(self):
        client = self.client([[call("ask_clarification", {"category": "marke"})]])
        result = run_agent(client, "fake", "Suche ein Auto", self.tools)
        self.assertEqual(result["status"], "rueckfrage")
        out = io.StringIO()
        with redirect_stdout(out):
            display_result(result)
        self.assertIn("Welche Fahrzeugmarke suchst du?", out.getvalue())
        self.assertIn("ungeprüft", out.getvalue())
        self.assertEqual(self.saved_status(), [])
        none = run_agent(self.client([[]]), "fake", "Hallo", self.tools)
        self.assertEqual(none["status"], "keine_analyse")

    def test_success_persisted_after_reopening(self):
        result = run_agent(self.client(self.save_steps() + [[]]), "fake", "Prüfe", self.tools)
        self.assertEqual(result["status"], "fertig")
        self.assertEqual(result["analyses"][0]["run_status"], "abgeschlossen")
        self.assertEqual(self.saved_status(), [("abgeschlossen",)])
        output = io.StringIO()
        with redirect_stdout(output):
            display_result(result)
        self.assertIn("Modellinterpretation, ungeprüft", output.getvalue())
        self.assertIn("Python-Marge: unbekannt", output.getvalue())
        self.assertIn("Kontakt ausstehend, Kauf ausstehend", output.getvalue())
        self.assertIn("Gespeicherter Auftragsstatus: abgeschlossen", output.getvalue())

    def test_saved_status_after_error_and_limit(self):
        for outcome in ("tool_error", "response_limit", "tool_limit", "api_error", "question"):
            with self.subTest(outcome=outcome):
                steps = self.save_steps()
                if outcome == "tool_error":
                    steps += [[call("unbekannt", {}, "3")], []]
                elif outcome == "tool_limit":
                    steps += [[call("get_vehicle_details", {"listing_id": "SYN-001"}, "3")]]
                elif outcome == "question":
                    steps += [[call("ask_clarification", {"category": "margeneingaben"}, "3")]]
                # Fehlende nächste Fake-Antwort simuliert einen Verbindungsfehler.
                result = run_agent(self.client(steps), "fake", "Prüfe", self.tools,
                                   max_tool_calls=2 if outcome == "tool_limit" else 8,
                                   max_responses=2 if outcome == "response_limit" else 10)
                self.assertNotEqual(result["status"], "fertig")
                expected = "vorlaeufig" if outcome == "question" else "unvollstaendig"
                self.assertEqual(result["analyses"][0]["run_status"], expected)
                self.assertEqual(self.saved_status()[-1], (expected,))

    def test_interrupted_save_remains_provisional(self):
        self.tools.get_vehicle_details("SYN-001")
        self.tools.save_analysis(**self.analysis)
        self.assertEqual(self.saved_status(), [("vorlaeufig",)])

    def test_old_database_migration_preserves_unknown(self):
        old = Path(self.temp.name) / "old.sqlite3"
        with closing(sqlite3.connect(old)) as db:
            for name in ("001-initial.sql", "002-synthetic-vehicles.sql"):
                db.executescript((ROOT / "memory" / "migrations" / name).read_text(encoding="utf-8"))
            db.execute("INSERT INTO listings VALUES ('SYN-001', 'synthetisch', 'fiktiv', '2026-01-01')")
            db.execute("INSERT INTO synthetic_vehicles VALUES ('SYN-001','BMW','Test',1,1,2020,'Ort','Radio',1)")
            db.execute("INSERT INTO analyses VALUES ('old', 'SYN-001', '{}', '2026-01-01')")
            db.commit()
        tools = LocalTools(old)
        self.assertEqual(read_analysis_statuses(old), [{"analysis_id": "old", "run_status": "unbekannt"}])
        tools.get_vehicle_details("SYN-001")
        tools.save_analysis(**self.analysis)
        tools.finalize_saved("abgeschlossen")
        with closing(sqlite3.connect(old)) as db:
            self.assertEqual(db.execute("SELECT run_status FROM analyses WHERE id='old'").fetchone()[0], "unbekannt")
            self.assertEqual(db.execute("SELECT COUNT(*) FROM synthetic_vehicles").fetchone()[0], 1)
            self.assertEqual(db.execute("SELECT COUNT(*) FROM analyses WHERE run_status='abgeschlossen'").fetchone()[0], 1)

    def test_no_invented_free_text_as_facts(self):
        client = self.client(self.save_steps() + [[]])
        original = client.responses.create
        def respond(**kwargs):
            response = original(**kwargs)
            response.output_text = "Marge 999999 EUR, Verkäufer kontaktiert, Auto gekauft"
            return response
        client.responses.create = respond
        result = run_agent(client, "fake", "Prüfe", self.tools)
        out = io.StringIO()
        with redirect_stdout(out):
            display_result(result)
        self.assertNotIn("999999", out.getvalue())
        self.assertNotIn("Auto gekauft", out.getvalue())
        self.assertIn("Python-Marge: unbekannt", out.getvalue())
        self.assertIn("Kontakt ausstehend, Kauf ausstehend", out.getvalue())

    def test_success_with_python_margin_and_model_claim(self):
        prices = {"listing_id": "SYN-001", "purchase_price": 17900, "incidental_costs": 350, "preparation_costs": 750, "sale_price": 21000}
        fake_analysis = {**self.analysis, "risks": ["Modell behauptet ungeprüft 999999 Euro Marge"]}
        steps = [[call("get_vehicle_details", {"listing_id": "SYN-001"}, "1")],
                 [call("calculate_margin", {**prices, "assumptions": "Nutzerangaben"}, "2")],
                 [call("save_analysis", fake_analysis, "3")], []]
        result = run_agent(self.client(steps), "fake", "Prüfe", self.tools, price_inputs=prices)
        out = io.StringIO()
        with redirect_stdout(out):
            display_result(result)
        self.assertEqual(result["status"], "fertig")
        self.assertEqual(self.saved_status(), [("abgeschlossen",)])
        self.assertIn("Modell, ungeprüft", out.getvalue())
        self.assertIn("Python-Marge: 2000.0 EUR", out.getvalue())
        self.assertNotIn("Python-Marge: 999999", out.getvalue())
        self.assertIn("Kontakt ausstehend, Kauf ausstehend", out.getvalue())

    def test_invalid_question_and_failed_status_update(self):
        client = self.client([[call("ask_clarification", {"category": "gekauft"})], []])
        result = run_agent(client, "fake", "Prüfe", self.tools)
        self.assertEqual(result["status"], "unvollstaendig")
        from orders import Orders
        real_update = Orders.update
        def fail_finish(store, order_id, state, status, *args, **kwargs):
            if status == "abgeschlossen":
                raise sqlite3.OperationalError("disk")
            return real_update(store, order_id, state, status, *args, **kwargs)
        with patch.object(Orders, "update", fail_finish):
            result = run_agent(self.client(self.save_steps() + [[]]), "fake", "Prüfe", self.tools)
        self.assertEqual(result["status"], "fehler")
        self.assertEqual(self.saved_status(), [("vorlaeufig",)])


if __name__ == "__main__":
    unittest.main(verbosity=2)
