"""Prüft Suche und Erstellung ausschließlich mit temporären Testdatenbanken."""
from contextlib import closing, redirect_stdout
import hashlib
import io
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from create_test_database import create_database
from vehicles import search_vehicles


class VehicleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "test.sqlite3"
        with redirect_stdout(io.StringIO()):
            create_database(self.path)

    def search(self, **kwargs):
        return search_vehicles(db_path=self.path, **kwargs)

    def test_new_database_has_exact_synthetic_ids(self):
        with closing(sqlite3.connect(self.path)) as db:
            rows = db.execute("SELECT l.id, v.is_synthetic, l.source_reference FROM listings l JOIN synthetic_vehicles v ON l.id = v.listing_id ORDER BY l.id").fetchall()
            self.assertEqual(db.execute("SELECT count(*) FROM listings").fetchone()[0], 30)
            self.assertEqual(db.execute("SELECT count(*) FROM synthetic_vehicles").fetchone()[0], 30)
            self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])
        self.assertEqual([row[0] for row in rows], [f"SYN-{i:03d}" for i in range(1, 31)])
        self.assertTrue(all(row[1] == 1 and "synthetische Testdaten" in row[2] for row in rows))

    def test_each_filter_and_boundaries(self):
        bmw = self.search(brand="bmw")
        self.assertEqual({v["id"] for v in bmw}, {f"SYN-{i:03d}" for i in range(1, 6)})
        prices = self.search(max_price=5900)
        self.assertEqual({v["id"] for v in prices}, {"SYN-005", "SYN-015"})
        miles = self.search(max_mileage=48000)
        self.assertEqual({v["id"] for v in miles}, {"SYN-015"})
        self.assertEqual(len(self.search()), 30)

    def test_combined_filters_and_no_matches(self):
        results = self.search(brand="BMW", max_price=17900, max_mileage=132000)
        self.assertEqual({v["id"] for v in results}, {"SYN-001", "SYN-002", "SYN-005"})
        self.assertEqual(self.search(brand="nicht vorhanden"), [])
        self.assertEqual(self.search(max_price=0), [])
        self.assertEqual(self.search(max_mileage=0), [])
        self.assertEqual(self.search(brand="BMW", max_price=1000, max_mileage=1000), [])

    def test_missing_database_is_not_created(self):
        missing = Path(self.temp.name) / "missing.sqlite3"
        with self.assertRaises(FileNotFoundError):
            search_vehicles(db_path=missing)
        self.assertFalse(missing.exists())

    def test_search_does_not_modify_database(self):
        before = hashlib.sha256(self.path.read_bytes()).digest()
        self.search(brand="Audi", max_price=20000, max_mileage=120000)
        self.assertEqual(hashlib.sha256(self.path.read_bytes()).digest(), before)
        self.assertEqual({p.name for p in self.path.parent.iterdir()}, {self.path.name})

    def test_existing_file_is_not_overwritten(self):
        before = self.path.read_bytes()
        with self.assertRaises(FileExistsError):
            create_database(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def test_connections_close_on_errors(self):
        bad = Path(self.temp.name) / "bad.sqlite3"
        with closing(sqlite3.connect(bad)) as db:
            db.execute("CREATE TABLE unrelated (id INTEGER)")
        with self.assertRaises(sqlite3.OperationalError):
            search_vehicles(db_path=bad)
        bad.unlink()
        target = Path(self.temp.name) / "failed.sqlite3"
        with patch("create_test_database.VEHICLES", [("unvollständig",)]):
            with self.assertRaises(ValueError):
                create_database(target)
        self.assertFalse(target.exists())

    def test_concrete_description_examples(self):
        descriptions = {v["id"]: v["description"].lower() for v in self.search()}
        examples = {"SYN-001": "scheckheft lückenlos", "SYN-002": "unfall",
                    "SYN-003": "unklar", "SYN-004": "motorwarnleuchte",
                    "SYN-005": "auffällig günstiger preis", "SYN-010": "widerspruch",
                    "SYN-018": "keine angabe"}
        for listing_id, phrase in examples.items():
            with self.subTest(listing_id=listing_id):
                self.assertIn(phrase, descriptions[listing_id])


if __name__ == "__main__":
    unittest.main(verbosity=2)
