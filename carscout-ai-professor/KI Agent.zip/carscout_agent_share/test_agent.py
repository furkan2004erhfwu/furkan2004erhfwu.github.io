"""Offline-Tests mit simulierten Responses; kein API-Schlüssel erforderlich."""
from contextlib import redirect_stdout, closing
import io
import copy
import json
from pathlib import Path
import sqlite3
import tempfile
from types import SimpleNamespace
import unittest

from agent import INSTRUCTIONS, run_agent
from agent_tools import LocalTools
from create_test_database import create_database


def call(name, arguments, call_id="c1"):
    return {"type": "function_call", "name": name, "arguments": json.dumps(arguments, ensure_ascii=False), "call_id": call_id}


class FakeResponses:
    def __init__(self, outputs):
        self.outputs, self.requests = iter(outputs), []

    def create(self, **kwargs):
        self.requests.append(copy.deepcopy(kwargs))
        return SimpleNamespace(output=next(self.outputs), output_text="Fertig", status="completed")


class AgentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "test.sqlite3"
        with redirect_stdout(io.StringIO()):
            create_database(self.path)
        self.tools = LocalTools(self.path)

    def client(self, outputs):
        self.fake = FakeResponses(outputs)
        return SimpleNamespace(responses=self.fake)

    def test_multiple_tools_and_saved_risk(self):
        search = {"brand": "BMW", "max_price": None, "max_mileage": None}
        analysis = {"listing_id": "SYN-004", "summary": "Weiter prüfen wegen Motorwarnleuchte", "facts": ["Inseratsangabe: Warnleuchte leuchtet"], "risks": ["Hinweis: möglicher Motorschaden"], "uncertainties": ["Offene Frage: Fehlerursache?"], "recommendation": "zurueckstellen"}
        client = self.client([[call("search_vehicles", search)], [call("get_vehicle_details", {"listing_id": "SYN-004"}, "c2")], [call("save_analysis", analysis, "c3")], []])
        result = run_agent(client, "fake-model", "Suche BMW und analysiere Risiken", self.tools)
        self.assertEqual(result["tool_calls"], 3)
        self.assertEqual(result["status"], "fertig")
        saved = result["analyses"][0]["analysis"]
        self.assertIn("Motorwarnleuchte", saved["summary"])
        self.assertIsNone(saved["margin"])
        self.assertEqual(saved["human_approval"]["purchase"], "ausstehend")
        self.assertIn("motorwarnleuchte", json.dumps(self.fake.requests[2]["input"], ensure_ascii=False).lower())
        with closing(sqlite3.connect(self.path)) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM analyses").fetchone()[0], 1)
        self.assertIn("untrusted", INSTRUCTIONS)

    def test_invalid_arguments_return_tool_error(self):
        client = self.client([[{"type": "function_call", "name": "search_vehicles", "arguments": "{", "call_id": "a"}], []])
        result = run_agent(client, "fake", "Suche", self.tools)
        self.assertEqual(result["status"], "unvollstaendig")
        self.assertIn("gültiges JSON", self.fake.requests[1]["input"][-1]["output"])
        self.assertIn("error", self.tools.execute("search_vehicles", {"brand": None, "max_price": -1, "max_mileage": None}))
        self.assertIn("error", self.tools.execute("unknown", {}))
        self.assertIn("error", self.tools.execute("get_vehicle_details", {"listing_id": "REAL-001"}))

    def test_margin_and_missing_input(self):
        self.tools.get_vehicle_details("SYN-001")
        values = {"listing_id": "SYN-001", "purchase_price": 17900, "incidental_costs": 350, "preparation_costs": 750, "sale_price": 21000, "assumptions": "Verkaufspreis vom Nutzer angenommen"}
        self.tools.set_price_inputs(**{k: v for k, v in values.items() if k != "assumptions"})
        margin = self.tools.calculate_margin(**values)
        self.assertEqual(margin["margin"]["amount"], 2000)
        self.assertEqual(margin["margin"]["inputs"]["sale_price"], 21000)
        values["sale_price"] = None
        self.assertIsNone(self.tools.calculate_margin(**values)["margin"])
        self.assertNotIn("SYN-001", self.tools.margins)
        values["sale_price"] = -10
        self.assertIn("error", self.tools.execute("calculate_margin", values))

    def test_unapproved_sale_price_is_rejected(self):
        self.tools.get_vehicle_details("SYN-001")
        values = {"listing_id": "SYN-001", "purchase_price": 17900, "incidental_costs": 350, "preparation_costs": 750, "sale_price": 21000, "assumptions": "erfunden"}
        self.assertFalse(self.tools.execute("calculate_margin", values)["complete"])
        self.assertNotIn("SYN-001", self.tools.margins)

    def test_margin_is_attached_from_python_to_saved_analysis(self):
        self.tools.get_vehicle_details("SYN-001")
        self.tools.set_price_inputs("SYN-001", 17900, 350, 750, 21000)
        self.tools.calculate_margin("SYN-001", 17900, 350, 750, 21000, "Nutzerannahme")
        result = self.tools.save_analysis("SYN-001", "Dieses Fahrzeug weiter prüfen", ["Inseratsangabe zum Kilometerstand"], ["Hinweis: Technischer Zustand ist unklar"], ["Preisannahme gründlich prüfen"], "weiter_pruefen")
        self.assertEqual(result["analysis"]["margin"]["amount"], 2000)

    def test_different_risk_cases_reach_model_as_data(self):
        cases = {"SYN-002": "Unfall", "SYN-003": "unklar", "SYN-004": "Motorwarnleuchte", "SYN-005": "günstiger", "SYN-009": "Getriebe", "SYN-010": "Widerspruch", "SYN-018": "Keine Angabe"}
        for listing, phrase in cases.items():
            with self.subTest(listing=listing):
                self.assertIn(phrase.lower(), self.tools.get_vehicle_details(listing)["vehicle"]["description"].lower())
        for concept in ("Unfall", "Motor", "Getriebe", "Wartung", "Widersprüche", "fehlende Angaben"):
            self.assertIn(concept, INSTRUCTIONS)

    def test_limit_counts_individual_calls(self):
        args = {"brand": None, "max_price": None, "max_mileage": None}
        client = self.client([[call("search_vehicles", args, "a"), call("search_vehicles", args, "b")]])
        result = run_agent(client, "fake", "Suche", self.tools, max_tool_calls=1)
        self.assertEqual(result["status"], "limit")
        self.assertEqual(result["tool_calls"], 1)

    def test_response_step_limit(self):
        client = self.client([[call("get_vehicle_details", {"listing_id": "SYN-001"})]])
        result = run_agent(client, "fake", "Suche", self.tools, max_responses=1)
        self.assertEqual(result["status"], "limit")

    def test_save_rejects_unseen_and_forged_margin(self):
        args = {"listing_id": "SYN-001", "summary": "Prüfen", "facts": [], "risks": [], "uncertainties": [], "recommendation": "weiter_pruefen"}
        self.assertIn("error", self.tools.execute("save_analysis", args))
        self.tools.get_vehicle_details("SYN-001")
        self.assertIn("error", self.tools.execute("save_analysis", {**args, "margin": 99999}))
        self.assertIn("error", self.tools.execute("save_analysis", args))


if __name__ == "__main__":
    unittest.main(verbosity=2)
