import io
import json
from contextlib import redirect_stdout
from pathlib import Path
import sys
import tempfile
import unittest
from codex_app_client import CodexAppClient, dynamic_tools
from codex_tool_bridge import CodexToolBridge
from create_test_database import create_database


class ClientTests(unittest.TestCase):
    def test_registration_and_error_reply(self):
        script = """import sys,json
for line in sys.stdin:
 m=json.loads(line)
 if m.get('method')=='initialize': print(json.dumps({'id':1,'result':{}}),flush=True)
 elif m.get('method')=='thread/start':
  tools=m['params']['dynamicTools']
  assert {t['name'] for t in tools}=={'search_vehicles','get_vehicle_details','calculate_margin'}
  assert all(t['type']=='function' and 'inputSchema' in t for t in tools)
  print(json.dumps({'method':'thread/started','params':{}}),flush=True)
  print(json.dumps({'id':2,'result':{'thread':{'id':'test-thread'}}}),flush=True)
  print(json.dumps({'id':42,'method':'item/tool/call','params':{'tool':'unknown','arguments':{},'threadId':'t','turnId':'u','callId':'c'}}),flush=True)
 elif m.get('id')==42: print(json.dumps({'method':'test/received','params':m['result']}),flush=True); break
"""
        client = CodexAppClient([sys.executable, '-u', '-c', script])
        try:
            client.start()
            self.assertEqual(client.register_tools(), 'test-thread')
            client.handle_next()
            response = client.receive()
            self.assertFalse(response['params']['success'])
            self.assertEqual(response['params']['contentItems'][0]['type'], 'inputText')
        finally: client.close()

    def test_registration_rejected(self):
        script = """import sys,json
for line in sys.stdin:
 m=json.loads(line)
 if m.get('method')=='initialize': print(json.dumps({'id':1,'result':{}}),flush=True)
 elif m.get('method')=='thread/start': print(json.dumps({'id':2,'error':{'code':-1,'message':'secret'}}),flush=True); break
"""
        client = CodexAppClient([sys.executable, '-u', '-c', script])
        try:
            client.start()
            with self.assertRaisesRegex(RuntimeError, 'abgelehnt'): client.register_tools()
        finally: client.close()

    def test_simulated_full_message_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(db)
            script = """import sys,json
for line in sys.stdin:
 m=json.loads(line)
 if m.get('method')=='initialize': print(json.dumps({'id':1,'result':{}}),flush=True)
 elif m.get('method')=='initialized': print(json.dumps({'id':42,'method':'item/tool/call','params':{'tool':'get_vehicle_details','arguments':{'listing_id':'SYN-001'},'threadId':'t','turnId':'u','callId':'c'}}),flush=True)
 elif m.get('id')==42: print(json.dumps({'method':'test/received','params':m['result']}),flush=True); break
"""
            client = CodexAppClient([sys.executable, '-u', '-c', script], CodexToolBridge(db))
            try:
                client.start(); client.handle_next(); received = client.receive()
                self.assertEqual(received['method'], 'test/received')
                self.assertTrue(received['params']['success'])
                self.assertEqual(json.loads(received['params']['contentItems'][0]['text'])['vehicle']['id'], 'SYN-001')
                self.assertEqual({t['name'] for t in dynamic_tools()}, CodexToolBridge.ALLOWED)
            finally: client.close()


if __name__ == '__main__': unittest.main()
