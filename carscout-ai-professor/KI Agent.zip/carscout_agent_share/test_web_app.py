"""Tests des lokalen Portals; kein echter Modellaufruf."""
from contextlib import closing, redirect_stdout
import http.client
import io
import json
from pathlib import Path
import sqlite3
import tempfile
import threading
from types import SimpleNamespace
import unittest
from http.server import ThreadingHTTPServer

from create_test_database import create_database
from test_agent import FakeResponses, call
from web_app import GermanTools, Repository, make_handler, run_request, calculate_manual_margin


class WebTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'data.sqlite3'
        with redirect_stdout(io.StringIO()):
            create_database(self.path)
        self.repo = Repository(self.path)

    def test_list_details_and_germany_boundary(self):
        self.assertEqual(len(self.repo.vehicles()), 30)
        self.assertEqual(self.repo.vehicle('SYN-001')['location'], 'Stuttgart')
        with closing(sqlite3.connect(self.path)) as db:
            with db:
                db.execute("UPDATE synthetic_vehicles SET location='Paris' WHERE listing_id='SYN-001'")
                db.execute("UPDATE synthetic_vehicles SET location='Unbekannt' WHERE listing_id='SYN-002'")
        self.assertIsNone(self.repo.vehicle('SYN-001'))
        self.assertIsNone(self.repo.vehicle('SYN-002'))
        self.assertEqual(len(self.repo.vehicles()), 28)
        tools = GermanTools(self.path)
        self.assertNotIn('SYN-001', [v['id'] for v in tools.search_vehicles(None,None,None)['vehicles']])
        self.assertIn('error', tools.execute('get_vehicle_details', {'listing_id':'SYN-001'}))
        with self.assertRaises(ValueError):
            self.repo.decide('SYN-001', 'gekauft')

    def test_decisions_are_local_and_persistent(self):
        for decision in ('vorgemerkt','pruefung','abgelehnt','gekauft'):
            self.repo.decide('SYN-001', decision)
            self.assertEqual(Repository(self.path).vehicle('SYN-001')['decision'], decision)
        with self.assertRaises(ValueError):
            self.repo.decide('SYN-001', 'extern_kaufen')

    def test_demo_and_live_consent(self):
        with redirect_stdout(io.StringIO()):
            demo=run_request(self.repo, {'mode':'demo','request':'BMW finden'})
        self.assertEqual(demo['mode'], 'demo')
        self.assertIn('Regelbasierte', demo['notice'])
        self.assertTrue(all(v['brand'] == 'BMW' for v in demo['result']['vehicles']))
        with self.assertRaises(ValueError):
            run_request(self.repo, {'mode':'live','request':'BMW finden','consent':False}, SimpleNamespace(responses=FakeResponses([])))
        with closing(sqlite3.connect(self.path)) as db:
            self.assertEqual(db.execute('SELECT count(*) FROM analyses').fetchone()[0], 0)

    def test_demo_search_examples_and_boundaries(self):
        examples = [
            ('Finde mir einen VW mit höchstens 100000 Kilometern.', ['SYN-018']),
            ('Zeige mir BMW unter 20000 Euro.', ['SYN-005', 'SYN-004', 'SYN-002', 'SYN-001']),
            ('Suche einen Audi A3 mit maximal 120000 km.', ['SYN-011']),
            ('Finde einen Mercedes unter 15000 Euro.', ['SYN-010']),
            ('Zeige mir einen Golf mit höchstens 80000 km.', []),
            ('VW mit höchstens 102000 km', ['SYN-018', 'SYN-016']),
            ('VW mit unter 102000 km', ['SYN-018']),
        ]
        for query, expected in examples:
            with self.subTest(query=query):
                result = run_request(self.repo, {'mode':'demo','request':query})['result']
                self.assertEqual(result['warnings'], [])
                self.assertEqual([v['id'] for v in result['vehicles']], expected)

    def test_demo_unknown_conditions_are_not_silently_ignored(self):
        for query in ('BMW Diesel', 'BMW oder Audi', 'BMW ab 2020', 'BMW unter 20000 Euro und unter 10000 Euro', 'Audi Golf'):
            with self.subTest(query=query):
                result = run_request(self.repo, {'mode':'demo','request':query})['result']
                self.assertTrue(result['warnings'])
                self.assertEqual(result['vehicles'], [])

    def test_demo_uses_current_database_and_germany_filter(self):
        with closing(sqlite3.connect(self.path)) as db:
            with db:
                db.execute("UPDATE synthetic_vehicles SET location='Paris' WHERE listing_id='SYN-018'")
        result = run_request(self.repo, {'mode':'demo','request':'VW mit höchstens 100000 km'})['result']
        self.assertEqual(result['vehicles'], [])

    def test_agent_question_and_resume(self):
        client = SimpleNamespace(responses=FakeResponses([[call('ask_clarification', {'category':'marke'}, 'q')], [call('get_vehicle_details', {'listing_id':'SYN-001'}, 'd')], [call('save_analysis', {'listing_id':'SYN-001','summary':'Dieses Fahrzeug gründlich überprüfen','facts':['Inseratsangabe: Wartung dokumentiert'],'risks':['Hinweis: Zustand muss geprüft werden'],'uncertainties':['Offene Frage: Liegen alle Belege vor?'],'recommendation':'weiter_pruefen'}, 'a')], []]))
        initial=run_request(self.repo, {'mode':'live','request':'Suche Fahrzeug','consent':True}, client)
        self.assertEqual(initial['result']['status'],'rueckfrage')
        oid=initial['result']['order_id']
        response=run_request(self.repo, {'mode':'live','request':'Fortsetzen','consent':True,'order_id':oid,'answer':'BMW'}, client)
        self.assertEqual(response['result']['status'],'fertig')
        self.assertEqual(response['result']['order_id'],oid)
        self.assertEqual(self.repo.vehicle('SYN-001')['analysis']['data']['listing_id'],'SYN-001')
        self.assertEqual(self.repo.vehicle('SYN-001')['analysis']['data']['margin'],None)
        self.assertEqual(self.repo.orders()[0]['status'],'abgeschlossen')

    def test_margin_only_from_existing_python_tool(self):
        prices = {'listing_id':'SYN-001','purchase_price':17900,'incidental_costs':350,'preparation_costs':750,'sale_price':21000}
        a={'listing_id':'SYN-001','summary':'Dieses Fahrzeug gründlich überprüfen','facts':['Inseratsangabe: Wartung dokumentiert'],'risks':['Hinweis: Zustand muss geprüft werden'],'uncertainties':['Offene Frage: Liegen alle Belege vor?'],'recommendation':'weiter_pruefen'}
        client = SimpleNamespace(responses=FakeResponses([[call('get_vehicle_details', {'listing_id':'SYN-001'}, 'd')], [call('calculate_margin', {**prices, 'assumptions':'Nutzerangaben'}, 'm')], [call('save_analysis', a, 'a')], []]))
        result=run_request(self.repo, {'mode':'live','request':'Prüfe Fahrzeug','consent':True,'price_inputs':prices}, client)
        self.assertEqual(result['result']['analyses'][0]['analysis']['margin']['amount'],2000)
        self.assertEqual(self.repo.vehicle('SYN-001')['analysis']['data']['margin']['amount'],2000)

    def test_manual_margin_and_incomplete_or_unapproved_inputs(self):
        data = {'listing_id':'SYN-001','purchase_price':17900,'incidental_costs':350,'preparation_costs':750,'sale_price':21000}
        self.assertEqual(calculate_manual_margin(self.repo, data)['margin']['amount'], 2000)
        for invalid in ({**data, 'sale_price':None}, {**data, 'purchase_price':-1}, {**data, 'sale_price':'21000'}, {**data, 'listing_id':'SYN-999'}):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                calculate_manual_margin(self.repo, invalid)
        with closing(sqlite3.connect(self.path)) as db:
            with db:
                db.execute("UPDATE synthetic_vehicles SET location='Paris' WHERE listing_id='SYN-001'")
        with self.assertRaises(ValueError): calculate_manual_margin(self.repo, data)

    def test_manual_margin_http_endpoint(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.repo))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
            conn.request('GET','/api/session');response=conn.getresponse();token=json.loads(response.read())['token']
            data={'listing_id':'SYN-001','purchase_price':17900,'incidental_costs':350,'preparation_costs':750,'sale_price':21000}
            conn.request('POST','/api/margin',body=json.dumps(data),headers={'Content-Type':'application/json','X-CarScout-Token':token});response=conn.getresponse()
            self.assertEqual(response.status,200);self.assertEqual(json.loads(response.read())['margin']['amount'],2000)
            data['sale_price']=None
            conn.request('POST','/api/margin',body=json.dumps(data),headers={'Content-Type':'application/json','X-CarScout-Token':token});response=conn.getresponse()
            self.assertEqual(response.status,400);response.read();conn.close()
        finally:
            server.shutdown();server.server_close();thread.join()

    def test_http_routes_and_csrf(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.repo))
        t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
        try:
            conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
            conn.request('GET','/api/vehicles');res=conn.getresponse();self.assertEqual(res.status,200);self.assertEqual(len(json.loads(res.read())['vehicles']),30)
            conn.request('GET','/api/vehicles/SYN-001');res=conn.getresponse();self.assertEqual(res.status,200);res.read()
            conn.request('GET','/api/vehicles/SYN-999');res=conn.getresponse();self.assertEqual(res.status,404);res.read()
            conn.request('POST','/api/decision',body='{}',headers={'Content-Type':'application/json'});res=conn.getresponse();self.assertEqual(res.status,403);res.read()
            conn.request('GET','/api/session');res=conn.getresponse();token=json.loads(res.read())['token']
            conn.request('POST','/api/decision',body=json.dumps({'id':'SYN-001','decision':'vorgemerkt'}),headers={'Content-Type':'application/json','X-CarScout-Token':token});res=conn.getresponse();self.assertEqual(res.status,200);res.read()
            conn.request('POST','/api/agent',body=json.dumps({'mode':'live','request':'BMW','consent':False}),headers={'Content-Type':'application/json','X-CarScout-Token':token});res=conn.getresponse();self.assertEqual(res.status,400);res.read()
            conn.close()
        finally:
            server.shutdown();server.server_close();t.join()


if __name__ == '__main__':
    unittest.main(verbosity=2)
