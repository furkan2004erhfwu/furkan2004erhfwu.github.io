-- Ergänzung zur Migration 001; nur für ausdrücklich synthetische Testanzeigen.
CREATE TABLE synthetic_vehicles (
    listing_id TEXT PRIMARY KEY NOT NULL REFERENCES listings(id),
    brand TEXT NOT NULL,
    model TEXT NOT NULL,
    price_eur INTEGER NOT NULL CHECK (price_eur >= 0),
    mileage_km INTEGER NOT NULL CHECK (mileage_km >= 0),
    year INTEGER NOT NULL CHECK (year BETWEEN 1886 AND 2100),
    location TEXT NOT NULL,
    equipment TEXT NOT NULL,
    is_synthetic INTEGER NOT NULL DEFAULT 1 CHECK (is_synthetic = 1)
);
