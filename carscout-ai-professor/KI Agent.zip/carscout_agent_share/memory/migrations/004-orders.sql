CREATE TABLE orders (
    id TEXT PRIMARY KEY NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('in_bearbeitung','wartet_auf_antwort','abgeschlossen','unvollstaendig','abgebrochen')),
    question TEXT,
    context_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
ALTER TABLE analyses ADD COLUMN order_id TEXT REFERENCES orders(id);
UPDATE analyses SET run_status = 'unbekannt' WHERE order_id IS NULL;
