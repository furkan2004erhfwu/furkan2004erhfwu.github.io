-- SQLite-Entwurf für Phase 1; Trinity-Vorgaben nicht überprüft.
-- Anwendung durch ein späteres Migrationswerkzeug genau einmal.
PRAGMA foreign_keys = ON;

CREATE TABLE listings (
    id TEXT PRIMARY KEY NOT NULL,
    source_reference TEXT NOT NULL,
    description TEXT,
    captured_at TEXT NOT NULL
);

CREATE TABLE analyses (
    id TEXT PRIMARY KEY NOT NULL,
    listing_id TEXT NOT NULL REFERENCES listings(id),
    result_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

-- Freigaben gelten jeweils für eine konkrete Analyse und Aktion.
CREATE TABLE approvals (
    id TEXT PRIMARY KEY NOT NULL,
    analysis_id TEXT NOT NULL REFERENCES analyses(id),
    action TEXT NOT NULL CHECK (action IN ('contact', 'purchase')),
    decision TEXT NOT NULL CHECK (decision IN ('approved', 'rejected')),
    decided_by TEXT NOT NULL,
    decided_at TEXT NOT NULL
);
