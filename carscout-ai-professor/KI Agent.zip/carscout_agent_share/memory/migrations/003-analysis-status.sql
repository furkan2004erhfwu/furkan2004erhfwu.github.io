-- Bestehende Analysen behalten ihren Inhalt; deren früherer Abschluss ist unbekannt.
ALTER TABLE analyses ADD COLUMN run_status TEXT NOT NULL DEFAULT 'unbekannt'
    CHECK (run_status IN ('unbekannt', 'vorlaeufig', 'unvollstaendig', 'abgeschlossen'));
