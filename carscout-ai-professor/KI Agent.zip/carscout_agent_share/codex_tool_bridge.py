"""Offline-Werkzeugbrücke für experimentelle Codex-App-Server-Anforderungen.

Startet keinen App Server und keinen Modellaufruf. Der aufrufende Client muss
die Antwort über denselben privaten App-Server-Kanal zurücksenden.
"""
import json
from web_app import GermanTools
from vehicles import DATABASE


class CodexToolBridge:
    ALLOWED = frozenset(('search_vehicles', 'get_vehicle_details', 'calculate_margin'))

    def __init__(self, db_path=DATABASE, price_inputs=None):
        self.tools = GermanTools(db_path)
        if price_inputs is not None:
            self.tools.set_price_inputs(**price_inputs)

    def handle(self, message):
        if not isinstance(message, dict) or 'id' not in message:
            raise ValueError('Eine App-Server-Anforderung mit ID ist erforderlich.')
        params = message.get('params')
        if message.get('method') != 'item/tool/call' or not isinstance(params, dict):
            return self._reply(message['id'], {'error': 'Ungültige Werkzeuganforderung.'}, False)
        name, args = params.get('tool'), params.get('arguments')
        if params.get('namespace') is not None or not isinstance(name, str) or name not in self.ALLOWED or not isinstance(args, dict):
            return self._reply(message['id'], {'error': 'Unbekanntes Werkzeug oder ungültige Argumente.'}, False)
        if any(not isinstance(params.get(key), str) or not params[key] for key in ('callId', 'threadId', 'turnId')):
            return self._reply(message['id'], {'error': 'Aufrufkennung fehlt.'}, False)
        result = self.tools.execute(name, args)
        return self._reply(message['id'], result, 'error' not in result)

    @staticmethod
    def _reply(request_id, result, success):
        return {'id': request_id, 'result': {'contentItems': [{'type': 'inputText', 'text': json.dumps(result, ensure_ascii=False, allow_nan=False)}], 'success': success}}
