"""Lokaler JSONL-Client: Initialisierung und Werkzeugdispatch, keine Modellstarts."""
import json
import queue
import sqlite3
import subprocess
import threading
import time
import uuid
from agent import TOOLS
from codex_tool_bridge import CodexToolBridge


def dynamic_tools():
    return [{'type': 'function', 'name': t['name'], 'description': t['description'], 'inputSchema': t['parameters']} for t in TOOLS if t['name'] in CodexToolBridge.ALLOWED]


class CodexAppClient:
    def __init__(self, command, bridge=None, timeout=15):
        self.command, self.bridge, self.timeout = command, bridge or CodexToolBridge(), timeout
        self.process = None
        self.messages = queue.Queue()
        self.order_service = None
        self.order_id = None

    def bind_order(self, order_service, order_id):
        if order_service.orders.read(order_id)['context'].get('provider') != 'codex':
            raise ValueError('Ungültiger Provider.')
        self.order_service, self.order_id = order_service, order_id

    def continue_order(self, *, allow_model_call=False):
        """Sendet eine vorbereitete Antwort; nur nach expliziter Zustimmung."""
        if allow_model_call is not True:
            raise PermissionError('Ein Modellaufruf benötigt ausdrückliche Zustimmung.')
        if self.order_service is None or self.order_id is None:
            raise ValueError('Kein Auftrag verbunden.')
        request_id = uuid.uuid4().hex
        request = self.order_service.claim_continuation(self.order_id, request_id)
        thread_id = request['params']['threadId']
        self.send(request)
        deadline = time.monotonic() + self.timeout
        response_turn = None
        started_turns = set()
        deferred = []
        try:
            return self._await_continuation(request_id, thread_id, deadline, response_turn, started_turns, deferred)
        finally:
            for message in deferred:
                self.messages.put(message)

    def _await_continuation(self, request_id, thread_id, deadline, response_turn, started_turns, deferred):
        while time.monotonic() < deadline:
            try:
                line = self.messages.get(timeout=max(0.01, deadline - time.monotonic()))
            except queue.Empty:
                raise TimeoutError('Fortsetzung nicht bestätigt; keine automatische Wiederholung.') from None
            if line is None:
                raise RuntimeError('App Server beendet; Fortsetzung unbestätigt.')
            try:
                msg = json.loads(line)
            except ValueError:
                raise RuntimeError('Ungültige Antwort; Fortsetzung unbestätigt.') from None
            if not isinstance(msg, dict):
                raise RuntimeError('Ungültige Antwort; Fortsetzung unbestätigt.')
            if msg.get('id') == request_id:
                result = msg.get('result')
                turn = result.get('turn') if isinstance(result, dict) else None
                if not isinstance(turn, dict) or not isinstance(turn.get('id'), str) or not turn['id'].strip():
                    raise RuntimeError('Fortsetzung nicht bestätigt; keine automatische Wiederholung.')
                response_turn = turn['id']
            elif msg.get('method') == 'turn/started':
                params = msg.get('params')
                turn = params.get('turn') if isinstance(params, dict) else None
                if isinstance(turn, dict) and isinstance(turn.get('id'), str) and params.get('threadId') == thread_id:
                    started_turns.add(turn['id'])
                else:
                    deferred.append(line)
            elif 'id' in msg and 'method' in msg:
                self.send({'id': msg['id'], 'error': {'code': -32601, 'message': 'Unsupported request'}})
            else:
                deferred.append(line)
            if response_turn is not None and response_turn in started_turns:
                self.order_service.confirm_continuation(self.order_id, thread_id, response_turn, request_id)
                return response_turn
        raise TimeoutError('Fortsetzung nicht bestätigt; keine automatische Wiederholung.')

    def start(self):
        self.process = subprocess.Popen(self.command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding='utf-8', bufsize=1)
        def read():
            for line in self.process.stdout:
                self.messages.put(line)
            self.messages.put(None)
        threading.Thread(target=read, daemon=True).start()
        try:
            self.send({'id': 1, 'method': 'initialize', 'params': {'clientInfo': {'name': 'carscout', 'version': '0.1'}, 'capabilities': {'experimentalApi': True}}})
            msg = self.receive()
            if msg.get('id') != 1 or not isinstance(msg.get('result'), dict):
                raise RuntimeError('Initialisierung abgelehnt.')
            self.send({'method': 'initialized', 'params': {}})
        except Exception:
            self.close()
            raise

    def send(self, message):
        self.process.stdin.write(json.dumps(message, ensure_ascii=False, allow_nan=False) + '\n')
        self.process.stdin.flush()

    def receive(self):
        try:
            line = self.messages.get(timeout=self.timeout)
        except queue.Empty:
            raise TimeoutError('Zeitlimit beim App Server erreicht.') from None
        if line is None:
            raise RuntimeError('App Server wurde beendet.')
        try:
            msg = json.loads(line)
        except ValueError:
            raise RuntimeError('Ungültige App-Server-Nachricht.') from None
        if not isinstance(msg, dict):
            raise RuntimeError('Ungültige App-Server-Nachricht.')
        return msg

    def handle_next(self):
        msg = self.receive()
        if msg.get('method') == 'item/tool/call' and 'id' in msg:
            self._dispatch_tool(msg)
        return msg

    def _dispatch_tool(self, msg):
        try:
            result = self.bridge.handle(msg) if self.order_service is None else self.order_service.handle_tool(self.order_id, msg)
        except Exception:
            result = CodexToolBridge._reply(msg['id'], {'error': 'Werkzeuganforderung abgelehnt.'}, False)
        self.send(result)

    def register_tools(self):
        """Startet einen kurzlebigen Thread; startet ausdrücklich keinen Modell-Turn."""
        self.send({'id': 2, 'method': 'thread/start', 'params': {'dynamicTools': dynamic_tools(), 'sandbox': 'read-only', 'approvalPolicy': 'never', 'ephemeral': True}})
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            try:
                line = self.messages.get(timeout=max(0.01, deadline-time.monotonic()))
            except queue.Empty:
                raise TimeoutError('Zeitlimit bei Werkzeugregistrierung.') from None
            if line is None:
                raise RuntimeError('App Server wurde beendet.')
            try:
                msg = json.loads(line)
            except ValueError:
                raise RuntimeError('Ungültige App-Server-Nachricht.') from None
            if msg.get('id') == 2:
                if 'error' in msg:
                    raise RuntimeError('App Server hat die Werkzeugregistrierung abgelehnt.')
                thread = msg.get('result', {}).get('thread', {})
                if not isinstance(thread.get('id'), str) or not thread['id']:
                    raise RuntimeError('Thread-Antwort enthält keine gültige ID.')
                return thread['id']
            if msg.get('method') == 'item/tool/call' and 'id' in msg:
                self._dispatch_tool(msg)
            elif 'id' in msg and 'method' in msg:
                self.send({'id': msg['id'], 'error': {'code': -32601, 'message': 'Unsupported request'}})
        raise TimeoutError('Zeitlimit bei Werkzeugregistrierung.')

    def close(self):
        if not self.process:
            return
        if self.process.stdin:
            self.process.stdin.close()
        try:
            self.process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        if self.process.stdout:
            self.process.stdout.close()
