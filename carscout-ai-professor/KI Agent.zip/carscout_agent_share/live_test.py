"""Einzeln bestätigter Live-Test mit temporärer Kopie der synthetischen Datenbank."""
from contextlib import closing
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
import uuid

from agent import display_result, run_agent
from agent_tools import DATABASE, LocalTools
from live_review import report_order
from orders import Orders

CASES = {
    '1': {'id': 'suche', 'target_id': 'SYN-001', 'request': 'Suche in den synthetischen Daten einen BMW bis 18000 Euro und 140000 km. Prüfe SYN-001 und speichere eine begründete Analyse.', 'prices': None},
    '2': {'id': 'risiko', 'target_id': 'SYN-004', 'request': 'Suche den synthetischen BMW 530d SYN-004, untersuche seine Beschreibung auf Risiken und speichere eine begründete Analyse. Berechne die Marge mit den separat erfassten Testwerten.', 'prices': {'listing_id': 'SYN-004', 'purchase_price': 8900, 'incidental_costs': 300, 'preparation_costs': 500, 'sale_price': 12000}},
    '3': {'id': 'rueckfrage', 'target_id': 'SYN-018', 'request': 'Prüfe das synthetische Fahrzeug SYN-018 und seine fehlenden Informationen. Bitte kläre vor der Analyse die fehlenden Margeneingaben mit einer Rückfrage.', 'prices': None},
}


def verify_test_data(db_path):
    with closing(sqlite3.connect(db_path.as_uri() + '?mode=ro', uri=True)) as db:
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok' or db.execute('PRAGMA foreign_key_check').fetchall():
            raise ValueError('Testdatenbank ist fehlerhaft.')
        rows = db.execute('SELECT l.id,v.is_synthetic,l.source_reference FROM listings l JOIN synthetic_vehicles v ON v.listing_id=l.id ORDER BY l.id').fetchall()
        total = db.execute('SELECT count(*) FROM listings').fetchone()[0]
        if total != 30 or [r[0] for r in rows] != [f'SYN-{i:03d}' for i in range(1, 31)] or not all(r[1] == 1 and 'synthetische Testdaten' in r[2] for r in rows):
            raise ValueError('Erwartete 30 synthetische Testfahrzeuge nicht gefunden.')


def main():
    print('Nur synthetische Testdaten. Pro Start wird genau ein Testfall gewählt.')
    choice = input('Testfall: 1 Suche, 2 Risiko und Marge, 3 Rückfrage: ').strip()
    if choice not in CASES:
        print('Ungültige Auswahl; keine API-Anfrage.'); return
    key = os.environ.get('OPENAI_API_KEY', '').strip()
    model = os.environ.get('OPENAI_MODEL', '').strip()
    if not key or not model:
        print('OPENAI_API_KEY oder OPENAI_MODEL fehlt; keine API-Anfrage.'); return
    try:
        from openai import OpenAI
    except ImportError:
        print('OpenAI-Paket fehlt; keine API-Anfrage.'); return
    case = CASES[choice]
    print('Testauftrag:', case['request'])
    print('Ein Test kann bis zu zehn Modellaufrufe umfassen und Kosten verursachen.')
    if input('Diesen einen Live-Test jetzt starten? [ja/NEIN] ').strip().lower() != 'ja':
        print('Abgebrochen; keine API-Anfrage.'); return
    try:
        verify_test_data(DATABASE)
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / 'test.sqlite3'
            shutil.copy2(DATABASE, db_path)
            verify_test_data(db_path)
            client = OpenAI(api_key=key, max_retries=0, timeout=60.0)
            result = run_agent(client, model, case['request'], tools=LocalTools(db_path), price_inputs=case['prices'])
            display_result(result)
            while result['status'] == 'rueckfrage':
                reply = input('Antwort (oder /abbrechen): ').strip()
                order = Orders(db_path).read(result['order_id'])
                values = None
                if reply and reply.lower() not in ('abbrechen', '/abbrechen') and order['context']['question_category'] == 'margeneingaben':
                    values = {'listing_id': input('Fahrzeug-ID: ').strip()}
                    for field, label in (('purchase_price', 'Einkaufspreis'), ('incidental_costs', 'Nebenkosten'), ('preparation_costs', 'Aufbereitung'), ('sale_price', 'Angenommener Verkaufspreis')):
                        raw = input(label + ' in EUR: ').strip().replace(',', '.')
                        try:
                            values[field] = float(raw) if raw else None
                        except ValueError:
                            values[field] = None
                result = run_agent(client, model, '', tools=LocalTools(db_path), resume_order_id=result['order_id'], answer=reply, price_inputs=values)
                display_result(result)
            report = report_order(db_path, result['order_id'], case)
            report['model'] = model
            report['created_at'] = datetime.now(timezone.utc).isoformat()
            report_dir = Path(__file__).resolve().parent / 'live_test_results'
            report_dir.mkdir(exist_ok=True)
            report_path = report_dir / (case['id'] + '-' + uuid.uuid4().hex + '.json')
            with report_path.open('x', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2, allow_nan=False)
            print('\nWerkzeugprotokoll und automatischer Teilvergleich:')
            print(json.dumps(report, ensure_ascii=False, indent=2))
            print('Gespeichert:', report_path)
    except (EOFError, KeyboardInterrupt):
        print('\nTest unterbrochen; kein vollständiges Protokoll erstellt.')
    except Exception as exc:
        print('Test nicht abgeschlossen:', type(exc).__name__, '(Details ohne Schlüssel prüfen).')


if __name__ == '__main__':
    main()
