"""Lokale Suche in den synthetischen CarScout-Testdaten (Python-Standardbibliothek)."""
from pathlib import Path
from contextlib import closing
import sqlite3

DATABASE = Path(__file__).resolve().parent / "memory" / "carscout-test.sqlite3"


def search_vehicles(brand=None, max_price=None, max_mileage=None, db_path=DATABASE):
    """Marke exakt (ohne Groß-/Kleinschreibung), Preis und Kilometer jeweils höchstens.

    Weggelassene Filter gelten nicht. Rückgabe: Liste von Dictionaries.
    Die Datenbank muss bereits existieren; diese Funktion erstellt keine Datei.
    """
    path = Path(db_path).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Testdatenbank nicht gefunden: {path}")
    query = """SELECT l.id, v.brand, v.model, v.price_eur, v.mileage_km,
                      v.year, v.location, v.equipment, l.description, v.is_synthetic
               FROM synthetic_vehicles v JOIN listings l ON l.id = v.listing_id
               WHERE v.is_synthetic = 1"""
    values = []
    if brand is not None:
        query += " AND v.brand = ? COLLATE NOCASE"
        values.append(brand)
    if max_price is not None:
        query += " AND v.price_eur <= ?"
        values.append(max_price)
    if max_mileage is not None:
        query += " AND v.mileage_km <= ?"
        values.append(max_mileage)
    query += " ORDER BY v.price_eur, l.id"
    # mode=ro verhindert versehentliche Änderungen über die Suche.
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as connection:
        connection.row_factory = sqlite3.Row
        return [dict(row) for row in connection.execute(query, values)]


if __name__ == "__main__":
    for vehicle in search_vehicles(brand="BMW", max_price=20000, max_mileage=150000):
        print(f"{vehicle['id']}: {vehicle['brand']} {vehicle['model']} | "
              f"{vehicle['price_eur']} EUR | {vehicle['mileage_km']} km | "
              f"{vehicle['year']} | {vehicle['location']} | SYNTHETISCH")
