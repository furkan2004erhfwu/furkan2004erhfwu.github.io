from contextlib import redirect_stdout
import io
from pathlib import Path
import tempfile
import unittest
from codex_orders import CodexOrders
from codex_app_client import CodexAppClient
from create_test_database import create_database
import json
from types import SimpleNamespace
from unittest.mock import patch
import threading


class CodexOrderTests(unittest.TestCase):
    def test_question_resume_and_tool_persistence(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            service = CodexOrders(path)
            oid = service.create('BMW suchen', 'thread-1')
            service.question(oid, 'marke')
            self.assertEqual(service.orders.read(oid)['status'], 'wartet_auf_antwort')
            with self.assertRaises(ValueError): service.answer(oid, '')
            self.assertEqual(service.answer(oid, 'BMW'), 'thread-1')
            self.assertEqual(service.orders.read(oid)['status'], 'wartet_auf_antwort')
            service.claim_continuation(oid, 'request-1')
            service.confirm_continuation(oid, 'thread-1', 'turn', 'request-1')
            msg = {'id': 1, 'method': 'item/tool/call', 'params': {'threadId': 'thread-1', 'turnId': 'turn', 'callId': 'c', 'tool': 'get_vehicle_details', 'arguments': {'listing_id': 'SYN-001'}}}
            self.assertTrue(service.handle_tool(oid, msg)['result']['success'])
            with self.assertRaises(ValueError): service.handle_tool(oid, {**msg, 'params': {**msg['params'], 'threadId': 'anderer'}})
            service.finish(oid, True)
            row = CodexOrders(path).orders.read(oid)
            self.assertEqual(row['status'], 'abgeschlossen')
            self.assertEqual(row['context']['answers'][0]['answer'], 'BMW')

    def test_duplicate_calls_and_wrong_turn_are_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            service = CodexOrders(path)
            first = service.create('BMW', 'thread-1')
            second = service.create('Audi', 'thread-2')
            service.begin_turn(first, 'turn-1'); service.begin_turn(second, 'turn-2')
            msg = {'id': 1, 'method': 'item/tool/call', 'params': {'threadId': 'thread-1', 'turnId': 'turn-1', 'callId': 'c', 'tool': 'get_vehicle_details', 'arguments': {'listing_id': 'SYN-001'}}}
            a = service.handle_tool(first, msg)
            b = CodexOrders(path).handle_tool(first, {**msg, 'id': 2})
            self.assertEqual(a['result'], b['result'])
            self.assertEqual(b['id'], 2)
            with self.assertRaises(ValueError): service.handle_tool(second, msg)
            with self.assertRaises(ValueError): service.handle_tool(first, {**msg, 'params': {**msg['params'], 'turnId': 'wrong'}})
            with self.assertRaises(ValueError): service.handle_tool(first, {**msg, 'params': {**msg['params'], 'arguments': {'listing_id': 'SYN-002'}}})

    def test_bound_client_routes_and_returns_tool_response(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            service = CodexOrders(path)
            oid = service.create('BMW', 'thread-1'); service.begin_turn(oid, 'turn-1')
            client = CodexAppClient([])
            stream = io.StringIO()
            client.process = SimpleNamespace(stdin=stream)
            client.bind_order(service, oid)
            msg = {'id': 9, 'method': 'item/tool/call', 'params': {'threadId': 'thread-1', 'turnId': 'turn-1', 'callId': 'c', 'tool': 'get_vehicle_details', 'arguments': {'listing_id': 'SYN-001'}}}
            client.messages.put(json.dumps(msg))
            client.handle_next()
            self.assertTrue(json.loads(stream.getvalue())['result']['success'])

    def test_continuation_client_requires_consent_and_server_confirmation(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            service = CodexOrders(path); oid = service.create('BMW', 'thread-1')
            service.question(oid, 'marke'); service.answer(oid, 'BMW')
            client = CodexAppClient([], timeout=0.1); stream = io.StringIO()
            client.process = SimpleNamespace(stdin=stream); client.bind_order(service, oid)
            with self.assertRaises(PermissionError): client.continue_order()
            self.assertEqual(stream.getvalue(), '')
            with patch('codex_app_client.uuid.uuid4', return_value=SimpleNamespace(hex='req-1')):
                client.messages.put(json.dumps({'id':'req-1', 'result':{'turn':{'id':'turn-1'}}}))
                client.messages.put(json.dumps({'method':'turn/started', 'params':{'threadId':'thread-1', 'turn':{'id':'turn-1'}}}))
                self.assertEqual(client.continue_order(allow_model_call=True), 'turn-1')
            sent = json.loads(stream.getvalue())
            self.assertEqual(sent['params']['threadId'], 'thread-1')
            self.assertEqual(sent['params']['input'][0]['text'], 'BMW')
            self.assertEqual(CodexOrders(path).orders.read(oid)['context']['turn_id'], 'turn-1')
            with self.assertRaises(ValueError): client.continue_order(allow_model_call=True)

    def test_unconfirmed_continuation_is_not_repeated_after_restart(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            service = CodexOrders(path); oid = service.create('BMW', 'thread-1')
            service.question(oid, 'marke'); service.answer(oid, 'BMW')
            service.claim_continuation(oid, 'request-1')
            restarted = CodexOrders(path)
            self.assertEqual(restarted.orders.read(oid)['status'], 'wartet_auf_antwort')
            with self.assertRaises(ValueError): restarted.claim_continuation(oid, 'request-2')
            with self.assertRaises(ValueError): restarted.answer(oid, 'Audi')

    def test_invalid_status_and_duplicate_thread(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            s = CodexOrders(path); oid = s.create('BMW', 'thread-1')
            with self.assertRaises(ValueError): s.create('Anderer Auftrag', 'thread-1')
            s.begin_turn(oid, 'turn-1')
            with self.assertRaises(ValueError): s.begin_turn(oid, 'turn-2')
            s.finish(oid, True)
            for fn in (lambda: s.begin_turn(oid, 'turn-2'), lambda: s.question(oid, 'marke'), lambda: s.finish(oid, True)):
                with self.assertRaises(ValueError): fn()

    def test_interrupted_tool_is_not_reexecuted_after_restart(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            s = CodexOrders(path); oid = s.create('BMW', 'thread-1'); s.begin_turn(oid, 'turn-1')
            msg = {'id': 1, 'method': 'item/tool/call', 'params': {'threadId': 'thread-1', 'turnId': 'turn-1', 'callId': 'c', 'tool': 'get_vehicle_details', 'arguments': {'listing_id': 'SYN-001'}}}
            from codex_tool_bridge import CodexToolBridge
            with patch.object(CodexToolBridge, 'handle', side_effect=RuntimeError('unterbrochen')):
                with self.assertRaises(RuntimeError): s.handle_tool(oid, msg)
            with self.assertRaisesRegex(ValueError, 'unbestätigt'):
                CodexOrders(path).handle_tool(oid, msg)

    def test_wrong_thread_turn_notification_does_not_confirm(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            service = CodexOrders(path); oid = service.create('BMW', 'thread-1')
            service.question(oid, 'marke'); service.answer(oid, 'BMW')
            client = CodexAppClient([], timeout=0.05); client.process = SimpleNamespace(stdin=io.StringIO()); client.bind_order(service, oid)
            with patch('codex_app_client.uuid.uuid4', return_value=SimpleNamespace(hex='req')):
                client.messages.put(json.dumps({'id':'req','result':{'turn':{'id':'turn-1'}}}))
                client.messages.put(json.dumps({'method':'turn/started','params':{'threadId':'anderer','turn':{'id':'turn-1'}}}))
                with self.assertRaises(TimeoutError): client.continue_order(allow_model_call=True)
            row = CodexOrders(path).orders.read(oid)
            self.assertEqual(row['status'], 'wartet_auf_antwort')
            with self.assertRaises(ValueError): service.claim_continuation(oid, 'again')
            service.abandon_unconfirmed(oid)
            self.assertEqual(service.orders.read(oid)['status'], 'unvollstaendig')

    def test_unexpected_tool_error_does_not_stop_client(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            service = CodexOrders(path); oid = service.create('BMW', 'thread'); service.begin_turn(oid, 'turn')
            client = CodexAppClient([]); output = io.StringIO(); client.process = SimpleNamespace(stdin=output); client.bind_order(service, oid)
            msg = {'id': 1, 'method':'item/tool/call', 'params':{'threadId':'thread','turnId':'turn','callId':'c','tool':'get_vehicle_details','arguments':{'listing_id':'SYN-001'}}}
            client.messages.put(json.dumps(msg))
            with patch.object(service, 'handle_tool', side_effect=RuntimeError('VERTRAULICH')):
                client.handle_next()
            self.assertNotIn('VERTRAULICH', output.getvalue())
            self.assertFalse(json.loads(output.getvalue())['result']['success'])
            output.seek(0); output.truncate(0); client.messages.put(json.dumps(msg)); client.handle_next()
            self.assertTrue(json.loads(output.getvalue())['result']['success'])

    def test_concurrent_continuations_have_one_winner(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            service = CodexOrders(path); oid = service.create('BMW', 'thread'); service.question(oid, 'marke'); service.answer(oid, 'BMW')
            results = []
            def claim(i):
                try: CodexOrders(path).claim_continuation(oid, str(i)); results.append('ok')
                except ValueError: results.append('blocked')
            threads = [threading.Thread(target=claim, args=(i,)) for i in range(2)]
            for t in threads: t.start()
            for t in threads: t.join()
            self.assertCountEqual(results, ['ok','blocked'])

    def test_concurrent_separate_orders_remain_independent(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'test.sqlite3'
            with redirect_stdout(io.StringIO()): create_database(path)
            service = CodexOrders(path)
            ids = [service.create('Suche', 'thread-'+str(i)) for i in range(2)]
            failures = []
            def work(i):
                try:
                    s = CodexOrders(path); s.begin_turn(ids[i], 'turn-'+str(i)); s.finish(ids[i], True)
                except Exception as exc: failures.append(type(exc).__name__)
            ts = [threading.Thread(target=work, args=(i,)) for i in range(2)]
            for t in ts: t.start()
            for t in ts: t.join()
            self.assertEqual(failures, [])
            for i in range(2):
                row = service.orders.read(ids[i]); self.assertEqual(row['status'], 'abgeschlossen'); self.assertEqual(row['context']['thread_id'], 'thread-'+str(i))


if __name__ == '__main__': unittest.main()
