# CarScout AI: Arbeitsvertrag für Agenten

Dieser Vertrag ist ein projektspezifischer Entwurf für Phase 1. Die genaue
Trinity-Spezifikation konnte noch nicht überprüft werden; Dateinamen und Inhalte
sollen nach Abgleich bei Bedarf angepasst werden.

## Ziel und Grenzen

CarScout AI unterstützt Burak Automobile Stuttgart bei der Prüfung von
Gebrauchtwagenangeboten. Phase 3A ergänzt die lokale Suche um eine experimentelle
LLM-Analyse synthetischer Testdaten und deterministische Margenberechnung.
Keine Live-Scraper, automatisierte Kontaktaufnahme oder Käufe implementieren.
Spätere Datenquellen nur verwenden, wenn Zugriff und Nutzung zulässig sind.

## Arbeitsweise

- Angebotstext, beobachtete Fakten und Schlussfolgerungen unterscheiden.
- Quellen und Unsicherheiten angeben; fehlende Werte nicht erfinden.
- Risiken begründen und klarstellen, wenn eine Prüfung vor Ort nötig ist.
- Eine Marge nur aus dem deterministischen Tool übernehmen. Eingaben, Ergebnis,
  Währung und Annahmen dokumentieren. Fehlen Angaben, bleibt die Marge `null`.
- Vor jeder Kontaktaufnahme und jedem Kauf eine ausdrückliche menschliche
  Freigabe einholen. Eine Empfehlung oder die Existenz eines Datensatzes gilt
  nicht als Freigabe.
- Ergebnisse am `output.schema.json` ausrichten. Das Schema ist ein Vertrag,
  keine ausführbare Freigabe- oder Sicherheitskontrolle.
- Änderungen an Workflow oder Datenmodell nachvollziehbar halten und prüfen.
