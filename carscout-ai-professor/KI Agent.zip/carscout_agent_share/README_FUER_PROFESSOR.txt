CarScout AI – geprüfter, teilbarer Quellcode-Stand
=================================================

Dieser Ordner ist ein aus den in der Chat-Unterhaltung verfügbaren Quellcode-Artefakten rekonstruierter und bereinigter Stand.

Unabhängig geprüft in dieser Umgebung:
- 70 automatisierte Tests: bestanden
- keine echten API-Keys, Passwörter oder Private Keys im Quellcode gefunden
- keine Tailscale-Inhalte oder privaten IP-Adressen gefunden
- lokale Weboberfläche bindet in der geprüften Version nur an 127.0.0.1:8765
- synthetische Testdatenbank enthält 30 Demo-Fahrzeuge und keine gespeicherten Analysen/Aufträge

Wichtig zur Einordnung:
Der auf dem Entwicklungsrechner aktuellste Präsentationsstand wurde später weiterentwickelt (u.a. finale Händler-Demo, zusätzliche UI-/KI-Funktionen). Dieser vollständige aktuelle Working Tree wurde nicht als kompletter Ordner in die Unterhaltung hochgeladen. Deshalb wird dieses Paket ausdrücklich nicht als bytegenaue Kopie des allerneuesten lokalen Stands ausgegeben.

Die Projekt-Timeline und der separate Sicherheitsprüfbericht dokumentieren auch die späteren, im Verlauf berichteten Meilensteine.

Keine Zugangsdaten sind enthalten. Eine .env.example-Datei enthält ausschließlich leere Platzhalter.
