"""Lokale Auftragszustände für Codex; startet selbst keine Modell-Turns."""
from agent import QUESTIONS
from codex_tool_bridge import CodexToolBridge
from orders import Orders
from contextlib import closing
import hashlib
import json
import sqlite3
import uuid
from orders import now


class CodexOrders:
    def __init__(self, db_path):
        self.orders = Orders(db_path)
        self.bridges = {}

    def create(self, request, thread_id):
        if not isinstance(request, str) or not request.strip() or len(request) > 4000:
            raise ValueError('Ungültiger Suchauftrag.')
        if not isinstance(thread_id, str) or not thread_id.strip() or len(thread_id) > 200:
            raise ValueError('Ungültige Thread-ID.')
        self.orders.migrate()
        oid = str(uuid.uuid4())
        state = {'provider': 'codex', 'request': request.strip(), 'thread_id': thread_id, 'turn_id': None, 'answers': [], 'results': [], 'category': None}
        with closing(self.orders.connect()) as db:
            with db:
                db.execute('BEGIN IMMEDIATE')
                for existing, in db.execute('SELECT context_json FROM orders'):
                    candidate = json.loads(existing)
                    if candidate.get('provider') == 'codex' and candidate.get('thread_id') == thread_id:
                        raise ValueError('Thread ist bereits einem Auftrag zugeordnet.')
                stamp = now()
                db.execute("INSERT INTO orders VALUES (?, 'in_bearbeitung', NULL, ?, ?, ?)", (oid, json.dumps(state, ensure_ascii=False), stamp, stamp))
        return oid

    @staticmethod
    def _validate(row, status):
        if row['status'] != status or row['context'].get('provider') != 'codex':
            raise ValueError('Ungültiger Status oder Provider.')

    def begin_turn(self, order_id, turn_id):
        if not isinstance(turn_id, str) or not turn_id.strip() or len(turn_id) > 200:
            raise ValueError('Ungültige Turn-ID.')
        with closing(self.orders.connect()) as db:
            with db:
                db.execute('BEGIN IMMEDIATE')
                row = db.execute('SELECT status,context_json FROM orders WHERE id=?', (order_id,)).fetchone()
                if not row:
                    raise ValueError('Auftrag nicht gefunden.')
                state = json.loads(row[1])
                if row[0] != 'in_bearbeitung' or state.get('provider') != 'codex' or state.get('turn_id') is not None:
                    raise ValueError('Auftrag ist nicht aktiv oder ein Turn läuft bereits.')
                state['turn_id'] = turn_id
                db.execute('UPDATE orders SET context_json=?,updated_at=? WHERE id=?', (json.dumps(state, ensure_ascii=False), now(), order_id))

    def question(self, order_id, category):
        if not isinstance(category, str) or category not in QUESTIONS:
            raise ValueError('Ungültige Rückfrage.')
        row = self.orders.read(order_id)
        self._validate(row, 'in_bearbeitung')
        state = row['context']
        state['category'] = category
        state['turn_id'] = None
        self.orders.update(order_id, state, 'wartet_auf_antwort', QUESTIONS[category])

    def answer(self, order_id, answer):
        if not isinstance(answer, str) or not answer.strip() or len(answer) > 4000:
            raise ValueError('Bitte eine gültige Antwort eingeben.')
        with closing(self.orders.connect()) as db:
            with db:
                db.execute('BEGIN IMMEDIATE')
                row = db.execute('SELECT status,context_json FROM orders WHERE id=?', (order_id,)).fetchone()
                if not row:
                    raise ValueError('Auftrag nicht gefunden.')
                state = json.loads(row[1])
                if row[0] != 'wartet_auf_antwort' or state.get('provider') != 'codex' or state.get('continuation_in_flight'):
                    raise ValueError('Auftrag wartet nicht oder Fortsetzung ist bereits übermittelt.')
                state['pending_answer'] = {'category': state['category'], 'answer': answer.strip()}
                db.execute('UPDATE orders SET context_json=?,updated_at=? WHERE id=?', (json.dumps(state, ensure_ascii=False), now(), order_id))
                return state['thread_id']

    def continuation_request(self, order_id, request_id):
        row = self.orders.read(order_id)
        self._validate(row, 'wartet_auf_antwort')
        pending = row['context'].get('pending_answer')
        if row['status'] != 'wartet_auf_antwort' or not isinstance(pending, dict):
            raise ValueError('Keine Antwort zur Fortsetzung vorhanden.')
        return {'id': request_id, 'method': 'turn/start', 'params': {'threadId': row['context']['thread_id'], 'input': [{'type': 'text', 'text': pending['answer'], 'text_elements': []}]}}

    def claim_continuation(self, order_id, request_id):
        with closing(self.orders.connect()) as db:
            with db:
                db.execute('BEGIN IMMEDIATE')
                row = db.execute('SELECT status,context_json FROM orders WHERE id=?', (order_id,)).fetchone()
                if not row:
                    raise ValueError('Auftrag nicht gefunden.')
                state = json.loads(row[1])
                if row[0] != 'wartet_auf_antwort' or state.get('provider') != 'codex' or not state.get('pending_answer') or state.get('continuation_in_flight'):
                    raise ValueError('Fortsetzung nicht verfügbar oder bereits übermittelt.')
                state['continuation_in_flight'] = request_id
                db.execute('UPDATE orders SET context_json=?,updated_at=? WHERE id=?', (json.dumps(state, ensure_ascii=False), now(), order_id))
                return {'id': request_id, 'method': 'turn/start', 'params': {'threadId': state['thread_id'], 'input': [{'type': 'text', 'text': state['pending_answer']['answer'], 'text_elements': []}]}}

    def confirm_continuation(self, order_id, thread_id, turn_id, request_id):
        with closing(self.orders.connect()) as db:
            with db:
                db.execute('BEGIN IMMEDIATE')
                row = db.execute('SELECT status,context_json FROM orders WHERE id=?', (order_id,)).fetchone()
                if not row:
                    raise ValueError('Auftrag nicht gefunden.')
                state = json.loads(row[1])
                if row[0] != 'wartet_auf_antwort' or state.get('provider') != 'codex' or state.get('thread_id') != thread_id or not state.get('pending_answer') or state.get('continuation_in_flight') != request_id or not isinstance(turn_id, str) or not turn_id.strip():
                    raise ValueError('Fortsetzung nicht eindeutig bestätigt.')
                state['answers'].append(state.pop('pending_answer'))
                state['category'] = None
                state['continuation_in_flight'] = None
                state['turn_id'] = turn_id
                db.execute("UPDATE orders SET status='in_bearbeitung', question=NULL, context_json=?, updated_at=? WHERE id=?", (json.dumps(state, ensure_ascii=False), now(), order_id))

    def abandon_unconfirmed(self, order_id):
        """Manuelle Entscheidung: unklaren Auftrag schließen, niemals erneut senden."""
        row = self.orders.read(order_id)
        self._validate(row, 'wartet_auf_antwort')
        if not row['context'].get('continuation_in_flight'):
            raise ValueError('Keine unbestätigte Fortsetzung vorhanden.')
        self.orders.update(order_id, row['context'], 'unvollstaendig', expected='wartet_auf_antwort')

    def handle_tool(self, order_id, message):
        row = self.orders.read(order_id)
        if not isinstance(message, dict) or 'id' not in message or message.get('method') != 'item/tool/call' or not isinstance(message.get('params'), dict):
            raise ValueError('Ungültige Werkzeuganforderung.')
        params = message['params']
        if row['status'] != 'in_bearbeitung' or row['context'].get('provider') != 'codex' or params.get('threadId') != row['context']['thread_id'] or not row['context'].get('turn_id') or params.get('turnId') != row['context']['turn_id']:
            raise ValueError('Werkzeuganforderung gehört nicht zum aktiven Auftrag.')
        call_id = params.get('callId')
        if not isinstance(call_id, str) or not call_id.strip() or len(call_id) > 200:
            raise ValueError('Ungültige Aufruf-ID.')
        fingerprint = hashlib.sha256(json.dumps(params, sort_keys=True, ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()
        with closing(self.orders.connect()) as db:
            with db:
                db.execute('CREATE TABLE IF NOT EXISTS codex_tool_calls (order_id TEXT NOT NULL, thread_id TEXT NOT NULL, turn_id TEXT NOT NULL, call_id TEXT NOT NULL, fingerprint TEXT NOT NULL, response TEXT, PRIMARY KEY (thread_id,turn_id,call_id))')
                found = db.execute('SELECT order_id,fingerprint,response FROM codex_tool_calls WHERE thread_id=? AND turn_id=? AND call_id=?', (params['threadId'], params['turnId'], call_id)).fetchone()
                if found:
                    if found[0] != order_id or found[1] != fingerprint:
                        raise ValueError('Aufruf-ID ist bereits anders belegt.')
                    if found[2] is None:
                        raise ValueError('Aufruf ist bereits in Bearbeitung oder unbestätigt.')
                    saved = json.loads(found[2]); saved['id'] = message['id']; return saved
                db.execute('INSERT INTO codex_tool_calls VALUES (?,?,?,?,?,NULL)', (order_id, params['threadId'], params['turnId'], call_id, fingerprint))
        bridge = self.bridges.setdefault(order_id, CodexToolBridge(self.orders.path))
        response = bridge.handle(message)
        with closing(self.orders.connect()) as db:
            with db:
                db.execute('UPDATE codex_tool_calls SET response=? WHERE thread_id=? AND turn_id=? AND call_id=?', (json.dumps(response, ensure_ascii=False, allow_nan=False), params['threadId'], params['turnId'], call_id))
        return response

    def finish(self, order_id, success):
        if not isinstance(success, bool):
            raise ValueError('Ungültiger Abschlussstatus.')
        row = self.orders.read(order_id)
        self._validate(row, 'in_bearbeitung')
        self.orders.update(order_id, row['context'], 'abgeschlossen' if success else 'unvollstaendig')
