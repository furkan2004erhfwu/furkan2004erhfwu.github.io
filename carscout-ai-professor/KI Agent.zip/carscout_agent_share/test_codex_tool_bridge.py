from contextlib import closing, redirect_stdout
import io
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from codex_tool_bridge import CodexToolBridge
from create_test_database import create_database


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / 'test.sqlite3'
        with redirect_stdout(io.StringIO()):
            create_database(self.db)
        self.prices = {'listing_id': 'SYN-001', 'purchase_price': 17900, 'incidental_costs': 350, 'preparation_costs': 750, 'sale_price': 21000}
        self.bridge = CodexToolBridge(self.db, self.prices)

    def call(self, name, args):
        return self.bridge.handle({'id': 7, 'method': 'item/tool/call', 'params': {'tool': name, 'arguments': args, 'threadId': 't', 'turnId': 'u', 'callId': 'c'}})

    def test_search_detail_and_margin_use_real_functions(self):
        search = self.call('search_vehicles', {'brand': 'BMW', 'max_price': 17900, 'max_mileage': 132000})
        self.assertEqual(search['id'], 7)
        self.assertEqual({v['id'] for v in json.loads(search['result']['contentItems'][0]['text'])['vehicles']}, {'SYN-001', 'SYN-002', 'SYN-005'})
        self.assertTrue(self.call('get_vehicle_details', {'listing_id': 'SYN-001'})['result']['success'])
        result = self.call('calculate_margin', {**self.prices, 'assumptions': 'Nutzerangaben'})
        self.assertEqual(json.loads(result['result']['contentItems'][0]['text'])['margin']['amount'], 2000)

    def test_invalid_unknown_and_unverified_price(self):
        self.assertFalse(self.call('save_analysis', {})['result']['success'])
        self.assertFalse(self.call('search_vehicles', {'brand': None, 'max_price': -1, 'max_mileage': None})['result']['success'])
        self.call('get_vehicle_details', {'listing_id': 'SYN-001'})
        self.assertFalse(self.call('calculate_margin', {**self.prices, 'sale_price': 22000, 'assumptions': 'x'})['result']['success'])

    def test_foreign_or_unknown_locations_are_blocked(self):
        with closing(sqlite3.connect(self.db)) as db:
            with db:
                db.execute("UPDATE synthetic_vehicles SET location='Paris' WHERE listing_id='SYN-001'")
        self.assertFalse(self.call('get_vehicle_details', {'listing_id': 'SYN-001'})['result']['success'])
        result = self.call('search_vehicles', {'brand': 'BMW', 'max_price': None, 'max_mileage': None})
        self.assertNotIn('SYN-001', [v['id'] for v in json.loads(result['result']['contentItems'][0]['text'])['vehicles']])


if __name__ == '__main__':
    unittest.main()
