"""Prüft YAML mit PyYAML und das deklarierte JSON-Schema mit jsonschema."""
import json
from pathlib import Path

import yaml
from jsonschema.validators import validator_for

ROOT = Path(__file__).resolve().parent
role = yaml.safe_load((ROOT / "role.yaml").read_text(encoding="utf-8"))
if not isinstance(role, dict):
    raise ValueError("role.yaml muss ein YAML-Objekt enthalten")
schema = json.loads((ROOT / "output.schema.json").read_text(encoding="utf-8"))
if schema.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
    raise ValueError("Unerwartete JSON-Schema-Version")
validator = validator_for(schema)
validator.check_schema(schema)
print("role.yaml: YAML-Syntax OK")
print("output.schema.json: Metaschema Draft 2020-12 OK")
