"""SQLite-Aufträge und atomare Statusübergänge. Kein Netzwerk, keine API-Schlüssel."""
from contextlib import closing
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
import uuid

ROOT = Path(__file__).resolve().parent


def now():
    return datetime.now(timezone.utc).isoformat()


class Orders:
    def __init__(self, path):
        self.path = Path(path).resolve()
        if not self.path.is_file():
            raise FileNotFoundError("Testdatenbank fehlt.")

    def connect(self):
        db = sqlite3.connect(self.path.as_uri() + "?mode=rw", uri=True)
        db.execute("PRAGMA foreign_keys=ON")
        return db

    def migrate(self):
        with closing(self.connect()) as db:
            with db:
                db.execute("BEGIN IMMEDIATE")
                columns = {r[1] for r in db.execute("PRAGMA table_info(analyses)")}
                if not columns:
                    raise sqlite3.DatabaseError("Tabelle analyses fehlt.")
                if "run_status" not in columns:
                    db.execute((ROOT / "memory/migrations/003-analysis-status.sql").read_text(encoding="utf-8"))
                columns = {r[1] for r in db.execute("PRAGMA table_info(analyses)")}
                if "order_id" not in columns:
                    sql = (ROOT / "memory/migrations/004-orders.sql").read_text(encoding="utf-8")
                    for statement in sql.split(";"):
                        if statement.strip():
                            db.execute(statement)
                elif not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='orders'").fetchone():
                    raise sqlite3.DatabaseError("Unvollständige Auftragsmigration.")

    def create(self, state):
        self.migrate()
        order_id = str(uuid.uuid4())
        stamp = now()
        with closing(self.connect()) as db:
            with db:
                db.execute("INSERT INTO orders VALUES (?, 'in_bearbeitung', NULL, ?, ?, ?)", (order_id, json.dumps(state, ensure_ascii=False, allow_nan=False), stamp, stamp))
        return order_id

    def read(self, order_id):
        with closing(sqlite3.connect(self.path.as_uri() + "?mode=ro", uri=True)) as db:
            row = db.execute("SELECT id,status,question,context_json,created_at,updated_at FROM orders WHERE id=?", (order_id,)).fetchone()
        if row is None:
            raise ValueError("Auftrag nicht gefunden.")
        return dict(zip(("id", "status", "question", "context", "created_at", "updated_at"), (*row[:3], json.loads(row[3]), *row[4:])))

    def update(self, order_id, state, status, question=None, expected="in_bearbeitung"):
        if status not in {"in_bearbeitung", "wartet_auf_antwort", "abgeschlossen", "unvollstaendig", "abgebrochen"}:
            raise ValueError("Ungültiger Auftragsstatus.")
        analysis_status = {"abgeschlossen": "abgeschlossen", "unvollstaendig": "unvollstaendig", "abgebrochen": "unvollstaendig"}.get(status)
        with closing(self.connect()) as db:
            with db:
                changed = db.execute("UPDATE orders SET status=?,question=?,context_json=?,updated_at=? WHERE id=? AND status=?", (status, question, json.dumps(state, ensure_ascii=False, allow_nan=False), now(), order_id, expected)).rowcount
                if changed != 1:
                    raise ValueError("Auftragsstatus hat sich geändert; Fortsetzung abgebrochen.")
                if analysis_status:
                    db.execute("UPDATE analyses SET run_status=? WHERE order_id=? AND run_status='vorlaeufig'", (analysis_status, order_id))
