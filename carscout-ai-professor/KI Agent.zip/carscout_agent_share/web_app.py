"""Lokales Händlerportal. Keine externen Aktionen; Agent nur mit Zustimmung."""
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json
import re
import os
import secrets
import sqlite3
import tempfile
import threading
from urllib.parse import urlparse, parse_qs

from agent import run_agent
from agent_tools import LocalTools, DATABASE
from create_test_database import VEHICLES, create_database
from orders import Orders
from vehicles import search_vehicles

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'web'
TOKEN = secrets.token_urlsafe(32)
DECISIONS = {'vorgemerkt', 'pruefung', 'abgelehnt', 'gekauft'}
# Die Ortsbestätigung gilt ausschließlich für die fest definierten synthetischen
# Testdatensätze. Keine Ableitung von Ländern aus freien Ortsnamen.
FIXTURES = {f'SYN-{i:03d}': row[5] for i, row in enumerate(VEHICLES, 1)}


class Repository:
    def __init__(self, path=DATABASE):
        self.path = Path(path).resolve()

    def connect(self, write=False):
        if not self.path.is_file():
            raise FileNotFoundError('Die lokale Testdatenbank fehlt.')
        db = sqlite3.connect(self.path.as_uri() + ('?mode=rw' if write else '?mode=ro'), uri=True)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        return db

    def vehicles(self):
        items = search_vehicles(db_path=self.path)
        with closing(self.connect()) as db:
            sources = {r['id']: r['source_reference'] for r in db.execute('SELECT id,source_reference FROM listings')}
            tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            decisions = {r['listing_id']: r['decision'] for r in db.execute('SELECT listing_id,decision FROM web_decisions')} if 'web_decisions' in tables else {}
            columns = {r['name'] for r in db.execute('PRAGMA table_info(analyses)')}
            statuses = "WHERE run_status='abgeschlossen'" if 'run_status' in columns else 'WHERE 0'
            latest = {}
            for row in db.execute('SELECT listing_id,result_json,created_at FROM analyses ' + statuses + ' ORDER BY created_at DESC'):
                if row['listing_id'] not in latest:
                    try:
                        a = json.loads(row['result_json'])
                        if isinstance(a, dict) and a.get('listing_id') == row['listing_id']:
                            latest[row['listing_id']] = {'data': a, 'created_at': row['created_at']}
                    except (ValueError, TypeError):
                        continue
        result = []
        for vehicle in items:
            vid = vehicle['id']
            if FIXTURES.get(vid) != vehicle['location'] or sources.get(vid) != 'synthetische Testdaten; keine externe Quelle' or vehicle['is_synthetic'] != 1:
                continue
            vehicle['country'] = 'Deutschland (synthetischer Teststandort)'
            vehicle['state'] = 'Baden-Württemberg'
            vehicle['decision'] = decisions.get(vid)
            vehicle['analysis'] = latest.get(vid)
            result.append(vehicle)
        return result

    def vehicle(self, vid):
        return next((v for v in self.vehicles() if v['id'] == vid), None)

    def init_web(self):
        with closing(self.connect(True)) as db:
            with db:
                db.execute('CREATE TABLE IF NOT EXISTS web_decisions (listing_id TEXT PRIMARY KEY REFERENCES listings(id), decision TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
                db.execute('CREATE TABLE IF NOT EXISTS web_orders (order_id TEXT PRIMARY KEY)')

    def decide(self, vid, decision):
        if not self.vehicle(vid):
            raise ValueError('Fahrzeug nicht gefunden oder Standort nicht bestätigt.')
        if decision not in DECISIONS:
            raise ValueError('Ungültige Entscheidung.')
        self.init_web()
        with closing(self.connect(True)) as db:
            with db:
                db.execute('INSERT INTO web_decisions(listing_id,decision) VALUES (?,?) ON CONFLICT(listing_id) DO UPDATE SET decision=excluded.decision,updated_at=CURRENT_TIMESTAMP', (vid, decision))

    def orders(self):
        with closing(self.connect()) as db:
            tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if 'orders' not in tables:
                return []
            return [dict(r) for r in db.execute('SELECT id,status,question,created_at,updated_at FROM orders ORDER BY updated_at DESC LIMIT 100')]

    def remember_order(self, oid):
        self.init_web()
        with closing(self.connect(True)) as db:
            with db:
                db.execute('INSERT OR IGNORE INTO web_orders VALUES (?)', (oid,))

    def can_resume(self, oid):
        with closing(self.connect()) as db:
            tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            return 'web_orders' in tables and bool(db.execute('SELECT 1 FROM web_orders WHERE order_id=?', (oid,)).fetchone())


class GermanTools(LocalTools):
    def search_vehicles(self, brand, max_price, max_mileage):
        result = super().search_vehicles(brand, max_price, max_mileage)
        allowed = {v['id'] for v in Repository(self.db_path).vehicles()}
        result['vehicles'] = [v for v in result['vehicles'] if v['id'] in allowed]
        return result

    def get_vehicle_details(self, listing_id):
        if not Repository(self.db_path).vehicle(listing_id):
            raise ValueError('Fahrzeug nicht verfügbar oder deutscher Teststandort nicht bestätigt.')
        return super().get_vehicle_details(listing_id)

    def calculate_margin(self, listing_id, *args, **kwargs):
        if not Repository(self.db_path).vehicle(listing_id):
            raise ValueError('Fahrzeug nicht verfügbar oder Standort nicht bestätigt.')
        return super().calculate_margin(listing_id, *args, **kwargs)

    def save_analysis(self, listing_id, *args, **kwargs):
        if not Repository(self.db_path).vehicle(listing_id):
            raise ValueError('Fahrzeug nicht verfügbar oder Standort nicht bestätigt.')
        return super().save_analysis(listing_id, *args, **kwargs)


def safe_result(result, repo):
    # Auch vorbestehende bzw. veränderte Datensätze dürfen nicht ausgegeben werden.
    result['analyses'] = [a for a in result.get('analyses', []) if repo.vehicle(a.get('analysis', {}).get('listing_id'))]
    return result


def calculate_manual_margin(repo, data):
    """Berechnet auf ausdrückliche Eingabe; kein Modell und keine Speicherung."""
    required = {'listing_id', 'purchase_price', 'incidental_costs', 'preparation_costs', 'sale_price'}
    if not isinstance(data, dict) or set(data) != required:
        raise ValueError('Bitte Fahrzeug und alle vier Beträge angeben.')
    if any(data[key] is None for key in required):
        raise ValueError('Bitte alle vier Beträge angeben.')
    tools = GermanTools(repo.path)
    tools.get_vehicle_details(data['listing_id'])
    tools.set_price_inputs(**data)
    return tools.calculate_margin(**data, assumptions='Vom Nutzer eingegebene Werte; Verkaufspreis ist eine Annahme.')


def demo_search(repo, request):
    """Konservative Suche: unerkannte Bedingungen verhindern Treffer."""
    text = request.casefold()
    filters = {'brand': None, 'model': None, 'max_price': None, 'max_mileage': None}
    limits, warnings = {}, []
    pattern = r'\b(höchstens|maximal|max\.?|bis(?: zu)?|unter|weniger als)\s+(\d[\d.]*)\s*(km|kilometern|kilometer|eur|euro|€)(?!\w)'
    def extract(m):
        qualifier, raw, unit = m.groups()
        if not re.fullmatch(r'\d+|\d{1,3}(?:\.\d{3})+', raw):
            warnings.append('Ungültige Zahl: ' + raw)
            return ' '
        key = 'max_mileage' if unit in ('km', 'kilometer', 'kilometern') else 'max_price'
        if key in limits:
            warnings.append('Mehrere Grenzen für ' + key)
        else:
            value = int(raw.replace('.', ''))
            filters[key] = value
            limits[key] = {'value': value, 'exclusive': qualifier in ('unter', 'weniger als')}
        return ' '
    text = re.sub(pattern, extract, text)
    aliases = {'vw':'Volkswagen','volkswagen':'Volkswagen','mercedes-benz':'Mercedes-Benz','mercedes':'Mercedes-Benz','benz':'Mercedes-Benz','bmw':'BMW','audi':'Audi','opel':'Opel','ford':'Ford','toyota':'Toyota','skoda':'Skoda','hyundai':'Hyundai','seat':'Seat','renault':'Renault'}
    brands = set()
    def extract_brand(m):
        brands.add(aliases[m.group()])
        return ' '
    text = re.sub(r'(?<![\w-])(?:' + '|'.join(sorted(map(re.escape, aliases), key=len, reverse=True)) + r')(?![\w-])', extract_brand, text)
    found = []
    for model, brand in sorted({(row[1].casefold(), row[0]) for row in VEHICLES}, key=lambda item: len(item[0]), reverse=True):
        match = re.search(r'(?<!\w)' + re.escape(model) + r'(?!\w)', text)
        if match:
            found.append((model, brand))
            text = text[:match.start()] + ' ' + text[match.end():]
    if len(brands) > 1 or len(found) > 1:
        warnings.append('Mehrere Marken oder Modelle sind nicht eindeutig unterstützt.')
    if len(brands) == 1:
        filters['brand'] = next(iter(brands))
    if len(found) == 1:
        model, model_brand = found[0]
        filters['model'] = next(row[1] for row in VEHICLES if row[1].casefold() == model)
        if filters['brand'] and filters['brand'] != model_brand:
            warnings.append('Marke und Modell passen nicht zusammen.')
        else:
            filters['brand'] = model_brand
    ignored = {'finde','mir','einen','ein','eine','fahrzeug','fahrzeuge','auto','autos','suche','such','zeige','zeig','bitte','mit','und','dem','der','das','den','ich','möchte','gerne','für','in','deutschland','zu','ist','haben'}
    unknown = [word for word in re.findall(r'[\w€-]+', text, flags=re.UNICODE) if word not in ignored]
    if unknown:
        warnings.append('Nicht erkannte oder mehrdeutige Angaben: ' + ', '.join(unknown))
    if not any(v is not None for v in filters.values()):
        warnings.append('Bitte mindestens Marke, Modell oder eine eindeutige Preis- bzw. Kilometergrenze angeben.')
    vehicles = []
    if not warnings:
        vehicles = GermanTools(repo.path).search_vehicles(filters['brand'], filters['max_price'], filters['max_mileage'])['vehicles']
        vehicles = [v for v in vehicles if (not filters['model'] or v['model'].casefold() == filters['model'].casefold()) and all(not limit['exclusive'] or v['price_eur' if key == 'max_price' else 'mileage_km'] < limit['value'] for key, limit in limits.items())]
    return {'filters': filters, 'limits': limits, 'warnings': warnings, 'vehicles': vehicles}


def run_request(repo, payload, client=None):
    mode = payload.get('mode')
    request = payload.get('request', '')
    if mode not in ('demo', 'live') or not isinstance(request, str) or not 1 <= len(request.strip()) <= 4000:
        raise ValueError('Bitte einen gültigen Suchauftrag eingeben.')
    if mode == 'demo':
        return {'mode': 'demo', 'notice': 'Regelbasierte Demo-Suche mit synthetischen Fahrzeugdaten – keine echte KI-Analyse.', 'result': demo_search(repo, request)}
    if payload.get('consent') is not True:
        raise ValueError('Bitte die kostenpflichtige KI-Anfrage ausdrücklich bestätigen.')
    key, model = os.environ.get('OPENAI_API_KEY', '').strip(), os.environ.get('OPENAI_MODEL', '').strip()
    if client is None:
        if not key or not model:
            raise ValueError('API-Schlüssel oder Modell fehlt auf dem Server.')
        try:
            from openai import OpenAI
        except ImportError:
            raise ValueError('Das OpenAI-Paket ist nicht installiert.')
        client = OpenAI(api_key=key, max_retries=0, timeout=60.0)
    model = model or 'simulation'
    oid = payload.get('order_id')
    if oid is not None and (not isinstance(oid, str) or not repo.can_resume(oid)):
        raise ValueError('Dieser Auftrag kann über die Weboberfläche nicht fortgesetzt werden.')
    answer = payload.get('answer')
    if oid and (not isinstance(answer, str) or len(answer) > 4000):
        raise ValueError('Bitte eine gültige Antwort eingeben.')
    result = run_agent(client, model, request, GermanTools(repo.path), resume_order_id=oid, answer=answer, price_inputs=payload.get('price_inputs'))
    repo.remember_order(result['order_id'])
    return {'mode': 'live', 'notice': 'Echte KI-Antwort; inhaltlich ungeprüft.', 'result': safe_result(result, repo)}


def make_handler(repo):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def send(self, code, data, content_type='application/json; charset=utf-8'):
            body = json.dumps(data, ensure_ascii=False).encode('utf-8') if content_type.startswith('application/json') else data
            self.send_response(code)
            self.send_header('Content-Type', content_type)
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'")
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def local(self):
            host = self.headers.get('Host', '').split(':')[0].lower()
            return self.client_address[0] in ('127.0.0.1', '::1') and host in ('127.0.0.1', 'localhost')

        def do_GET(self):
            if not self.local():
                return self.send(403, {'error': 'Nur lokal verfügbar.'})
            path = urlparse(self.path).path
            assets = {'/': ('index.html', 'text/html; charset=utf-8'), '/app.js': ('app.js', 'text/javascript; charset=utf-8'), '/style.css': ('style.css', 'text/css; charset=utf-8'), '/logo.png': ('logo.png', 'image/png')}
            try:
                if path in assets:
                    name, mime = assets[path]
                    return self.send(200, (ASSETS / name).read_bytes(), mime)
                if path == '/api/session':
                    return self.send(200, {'token': TOKEN, 'live_configured': bool(os.environ.get('OPENAI_API_KEY') and os.environ.get('OPENAI_MODEL'))})
                if path == '/api/vehicles':
                    return self.send(200, {'vehicles': repo.vehicles()})
                if path.startswith('/api/vehicles/'):
                    item = repo.vehicle(path.rsplit('/', 1)[-1])
                    return self.send(200, {'vehicle': item}) if item else self.send(404, {'error': 'Fahrzeug nicht verfügbar.'})
                if path == '/api/orders':
                    return self.send(200, {'orders': repo.orders()})
                return self.send(404, {'error': 'Nicht gefunden.'})
            except (OSError, sqlite3.Error, ValueError):
                return self.send(500, {'error': 'Lokale Daten konnten nicht geladen werden.'})

        def do_POST(self):
            if not self.local() or self.headers.get('X-CarScout-Token') != TOKEN:
                return self.send(403, {'error': 'Ungültige lokale Sitzung.'})
            origin = self.headers.get('Origin')
            if origin and origin != f'http://{self.headers.get("Host")}':
                return self.send(403, {'error': 'Ungültiger Ursprung.'})
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if length < 2 or length > 30000:
                    raise ValueError('Ungültige Eingabegröße.')
                data = json.loads(self.rfile.read(length))
                if not isinstance(data, dict):
                    raise ValueError('Ungültige Eingabe.')
                if self.path == '/api/decision':
                    repo.decide(data.get('id'), data.get('decision'))
                    return self.send(200, {'ok': True})
                if self.path == '/api/agent':
                    return self.send(200, run_request(repo, data))
                if self.path == '/api/margin':
                    return self.send(200, calculate_manual_margin(repo, data))
                return self.send(404, {'error': 'Nicht gefunden.'})
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                return self.send(400, {'error': str(exc)})
            except (OSError, sqlite3.Error):
                return self.send(500, {'error': 'Die Anfrage konnte lokal nicht verarbeitet werden.'})
            except Exception:
                return self.send(500, {'error': 'Die KI-Anfrage konnte nicht abgeschlossen werden.'})
    return Handler


def main():
    server = ThreadingHTTPServer(('127.0.0.1', 8765), make_handler(Repository()))
    print('CarScout AI: http://127.0.0.1:8765 — beenden mit Strg+C', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
