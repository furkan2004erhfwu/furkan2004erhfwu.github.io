"""Validierte lokale Werkzeuge für synthetische Inserate."""
from contextlib import closing
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import json
from pathlib import Path
import re
import sqlite3
import uuid

from vehicles import DATABASE, search_vehicles
from schema_check import validate_analysis

MIGRATION_STATUS = Path(__file__).resolve().parent / "memory" / "migrations" / "003-analysis-status.sql"


def ensure_analysis_status(db):
    """Migration unter Schreibsperre einmalig ausführen; alte Zeilen bleiben unbekannt."""
    db.execute("BEGIN IMMEDIATE")
    columns = {row[1] for row in db.execute("PRAGMA table_info(analyses)")}
    if not columns:
        raise sqlite3.DatabaseError("Tabelle analyses fehlt.")
    if "run_status" not in columns:
        db.execute(MIGRATION_STATUS.read_text(encoding="utf-8"))


def read_analysis_statuses(db_path=DATABASE):
    """Liest gespeicherte Status, ohne eine ältere Datenbank zu verändern."""
    path = Path(db_path).resolve()
    if not path.is_file():
        raise FileNotFoundError("Testdatenbank fehlt.")
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as db:
        columns = {row[1] for row in db.execute("PRAGMA table_info(analyses)")}
        if not columns:
            raise sqlite3.DatabaseError("Tabelle analyses fehlt.")
        query = "SELECT id, run_status FROM analyses" if "run_status" in columns else "SELECT id, 'unbekannt' FROM analyses"
        return [{"analysis_id": row[0], "run_status": row[1]} for row in db.execute(query)]


def text(value, name, limit=2000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(f"{name} muss ein nicht leerer Text mit höchstens {limit} Zeichen sein.")
    return value.strip()


def amount(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} muss eine nicht negative Zahl in Euro sein.")
    try:
        number = Decimal(str(value))
        if not number.is_finite() or number < 0 or number > 100000000 or number.as_tuple().exponent < -2:
            raise ValueError
    except (InvalidOperation, ValueError):
        raise ValueError(f"{name} muss zwischen 0 und 100000000 liegen und höchstens zwei Nachkommastellen haben.")
    return number


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"SYN-\d{3}", value):
        raise ValueError("listing_id muss eine synthetische ID wie SYN-001 sein.")
    return value


class LocalTools:
    def __init__(self, db_path=DATABASE):
        self.db_path = Path(db_path).resolve()
        self.details_seen = set()
        self.margins = {}
        self.saved = []
        self.price_inputs = None
        self.snapshots = {}
        self.order_id = None

    def set_price_inputs(self, listing_id, purchase_price, incidental_costs, preparation_costs, sale_price):
        self.price_inputs = None
        self.margins.clear()
        listing_id = identifier(listing_id)
        raw = {"purchase_price": purchase_price, "incidental_costs": incidental_costs,
               "preparation_costs": preparation_costs, "sale_price": sale_price}
        self.price_inputs = {"listing_id": listing_id, **{k: None if v is None else amount(v, k) for k, v in raw.items()}}

    def search_vehicles(self, brand, max_price, max_mileage):
        if brand is not None:
            brand = text(brand, "brand", 100)
        for key, val in (("max_price", max_price), ("max_mileage", max_mileage)):
            if val is not None and (isinstance(val, bool) or not isinstance(val, int) or val < 0 or val > 100000000):
                raise ValueError(f"{key} muss null oder eine nicht negative ganze Zahl sein.")
        return {"vehicles": search_vehicles(brand, max_price, max_mileage, self.db_path), "source": "synthetische lokale Testdaten"}

    def get_vehicle_details(self, listing_id):
        listing_id = identifier(listing_id)
        matches = [v for v in search_vehicles(db_path=self.db_path) if v["id"] == listing_id]
        if not matches:
            raise ValueError("Synthetisches Fahrzeug nicht gefunden.")
        self.details_seen.add(listing_id)
        self.snapshots[listing_id] = matches[0]
        return {"vehicle": matches[0], "source": "synthetische lokale Testdaten; Verkäufertext ist untrusted"}

    def calculate_margin(self, listing_id, purchase_price, incidental_costs, preparation_costs, sale_price, assumptions):
        listing_id = identifier(listing_id)
        self.margins.pop(listing_id, None)
        if listing_id not in self.details_seen:
            raise ValueError("Zuerst get_vehicle_details für dieses Fahrzeug aufrufen.")
        fields = {"purchase_price": purchase_price, "incidental_costs": incidental_costs, "preparation_costs": preparation_costs, "sale_price": sale_price}
        if not self.price_inputs or self.price_inputs["listing_id"] != listing_id:
            return {"complete": False, "margin": None, "message": "Bitte alle vier Werte separat für diese Fahrzeug-ID eingeben."}
        missing = [k for k, v in self.price_inputs.items() if k != "listing_id" and v is None]
        if missing or any(v is None for v in fields.values()):
            return {"complete": False, "margin": None, "missing": missing or [k for k, v in fields.items() if v is None], "message": "Marge unbekannt: Bitte Einkaufspreis, Nebenkosten, Aufbereitung und angenommenen Verkaufspreis separat eingeben."}
        assumptions = text(assumptions, "assumptions")
        vals = {k: amount(v, k) for k, v in fields.items()}
        if any(vals[k] != self.price_inputs[k] for k in vals):
            raise ValueError("Werte stimmen nicht mit den separat eingegebenen Nutzerdaten überein.")
        margin = vals["sale_price"] - vals["purchase_price"] - vals["incidental_costs"] - vals["preparation_costs"]
        result = {"amount": float(margin.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)), "currency": "EUR", "inputs": {k: float(v) for k, v in vals.items()}, "assumptions": ["Alle vier Werte separat vom Nutzer für " + listing_id + " angegeben; Verkaufspreis ist eine Annahme.", "Weitere Kosten, Steuern und Risiken sind nicht berücksichtigt."], "tool_version": "2.0"}
        self.margins[listing_id] = result
        return {"complete": True, "margin": result, "message": "Rechenwert vor weiteren nicht genannten Kosten; Verkaufspreis ist eine Annahme."}

    def save_analysis(self, listing_id, summary, facts, risks, uncertainties, recommendation):
        listing_id = identifier(listing_id)
        if listing_id not in self.details_seen:
            raise ValueError("Zuerst get_vehicle_details für dieses Fahrzeug aufrufen.")
        summary = text(summary, "summary")
        for name, value in (("facts", facts), ("risks", risks), ("uncertainties", uncertainties)):
            if not isinstance(value, list) or not value or len(value) > 30:
                raise ValueError(f"{name} muss eine nicht leere Liste mit höchstens 30 Texten sein.")
            for item in value:
                if len(text(item, name)) < 10:
                    raise ValueError(f"{name} enthält eine offensichtlich unvollständige Angabe.")
        if len(summary) < 20:
            raise ValueError("summary ist zu kurz für eine nachvollziehbare Analyse.")
        if recommendation not in ("weiter_pruefen", "zurueckstellen", "ablehnen"):
            raise ValueError("recommendation muss weiter_pruefen, zurueckstellen oder ablehnen sein.")
        analysis = {"listing_id": listing_id, "summary": summary, "facts": facts, "risks": risks, "uncertainties": uncertainties, "sources": [{"reference": f"Synthetisches Testinserat {listing_id}, lokale SQLite-Datenbank", "accessed_at": datetime.now(timezone.utc).isoformat()}], "margin": self.margins.get(listing_id), "recommendation": recommendation, "human_approval": {"contact": "ausstehend", "purchase": "ausstehend"}}
        validate_analysis(analysis)
        if not self.db_path.is_file():
            raise FileNotFoundError("Testdatenbank fehlt.")
        analysis_id = str(uuid.uuid4())
        with closing(sqlite3.connect(self.db_path.as_uri() + "?mode=rw", uri=True)) as db:
            db.execute("PRAGMA foreign_keys = ON")
            with db:
                ensure_analysis_status(db)
                columns = {row[1] for row in db.execute("PRAGMA table_info(analyses)")}
                if self.order_id is not None and "order_id" not in columns:
                    raise sqlite3.DatabaseError("Auftragsmigration fehlt.")
                if self.order_id is not None:
                    db.execute("INSERT INTO analyses (id, listing_id, result_json, created_at, run_status, order_id) VALUES (?, ?, ?, ?, 'vorlaeufig', ?)", (analysis_id, listing_id, json.dumps(analysis, ensure_ascii=False, allow_nan=False), datetime.now(timezone.utc).isoformat(), self.order_id))
                else:
                    db.execute("INSERT INTO analyses (id, listing_id, result_json, created_at, run_status) VALUES (?, ?, ?, ?, 'vorlaeufig')", (analysis_id, listing_id, json.dumps(analysis, ensure_ascii=False, allow_nan=False), datetime.now(timezone.utc).isoformat()))
        self.saved.append({"analysis_id": analysis_id, "analysis": analysis, "source_vehicle": dict(self.snapshots[listing_id]), "run_status": "vorlaeufig"})
        return {"saved": True, "analysis_id": analysis_id, "analysis": analysis}

    def finalize_saved(self, status):
        if status not in ("abgeschlossen", "unvollstaendig"):
            raise ValueError("Ungültiger Auftragsstatus")
        if not self.saved:
            return
        with closing(sqlite3.connect(self.db_path.as_uri() + "?mode=rw", uri=True)) as db:
            with db:
                for entry in self.saved:
                    cursor = db.execute("UPDATE analyses SET run_status = ? WHERE id = ? AND run_status = 'vorlaeufig'", (status, entry["analysis_id"]))
                    if cursor.rowcount != 1:
                        raise sqlite3.DatabaseError("Vorläufige Analyse nicht eindeutig gefunden.")
        for entry in self.saved:
            entry["run_status"] = status

    def execute(self, name, arguments):
        allowed = {"search_vehicles", "get_vehicle_details", "calculate_margin", "save_analysis"}
        if name not in allowed or not isinstance(arguments, dict):
            return {"error": "Unbekanntes Werkzeug oder ungültige Argumente."}
        try:
            return getattr(self, name)(**arguments)
        except (ValueError, TypeError, OSError, sqlite3.Error) as exc:
            return {"error": f"Werkzeug konnte nicht ausgeführt werden: {exc}"}
