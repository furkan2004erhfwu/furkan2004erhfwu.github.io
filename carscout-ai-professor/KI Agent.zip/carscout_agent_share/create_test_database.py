"""Erstellt die lokale Testdatenbank einmalig; überschreibt keine bestehende Datei."""
from pathlib import Path
from contextlib import closing
import sqlite3
from vehicles import DATABASE

ROOT = Path(__file__).resolve().parent
# Sämtliche Namen, Preise und Beschreibungen sind frei erfunden.
# Marke, Modell, Preis, km, Jahr, Ort, Ausstattung, Beschreibung
VEHICLES = [
    ("BMW", "320d", 17900, 132000, 2017, "Stuttgart", "Navi, Klimaautomatik", "Scheckheft lückenlos, Wartungen mit Rechnungen dokumentiert."),
    ("BMW", "118i", 13900, 92000, 2018, "Esslingen", "Sitzheizung, PDC", "Heckschaden nach Unfall, Reparatur laut Verkäufer erfolgt; Belege fehlen."),
    ("BMW", "X1", 21900, 86000, 2019, "Ludwigsburg", "LED, Automatik", "Historie aus Import unklar, Vorbesitzer unbekannt."),
    ("BMW", "530d", 8900, 195000, 2014, "Heilbronn", "Leder, Navi", "Motorwarnleuchte leuchtet, zeitweise Leistungsverlust."),
    ("BMW", "i3", 5900, 72000, 2020, "Böblingen", "Kamera, LED", "Auffällig günstiger Preis; Zustand der Batterie nicht bekannt."),
    ("Mercedes-Benz", "C 200", 19900, 110000, 2018, "Stuttgart", "Navi, Automatik", "Wartungshistorie vollständig mit Rechnungen."),
    ("Mercedes-Benz", "A 180", 15700, 87000, 2019, "Ulm", "Klimaanlage, PDC", "Unfall an der Fahrertür, Instandsetzung nicht dokumentiert."),
    ("Mercedes-Benz", "E 220 d", 24500, 142000, 2019, "Karlsruhe", "Leder, Navi", "Historie unklar, Serviceheft laut Verkäufer verloren."),
    ("Mercedes-Benz", "GLA 200", 22900, 69000, 2020, "Reutlingen", "LED, Kamera", "Getriebe ruckelt beim Schalten im kalten Zustand."),
    ("Mercedes-Benz", "B 180", 9900, 125000, 2016, "Tübingen", "Tempomat, PDC", "Inserat nennt unfallfrei, Beschreibung erwähnt reparierten Unfallschaden: Widerspruch."),
    ("Audi", "A3", 16900, 98000, 2018, "Stuttgart", "Navi, LED", "Scheckheft vollständig, letzter Service dokumentiert."),
    ("Audi", "A4 Avant", 18700, 155000, 2017, "Pforzheim", "Automatik, Anhängerkupplung", "Nach Auffahrunfall repariert; Schadenshöhe unbekannt."),
    ("Audi", "Q3", 24900, 79000, 2020, "Baden-Baden", "Kamera, Sitzheizung", "Wartungshistorie unklar; nur ein Schlüssel vorhanden."),
    ("Audi", "A6", 12900, 210000, 2015, "Göppingen", "Leder, Navi", "Kühlmittelverlust und weißer Rauch beim Start."),
    ("Audi", "A1", 4900, 48000, 2021, "Sindelfingen", "Klima, Bluetooth", "Auffällig günstiger Preis, Verkäufer nennt keinen Grund."),
    ("Volkswagen", "Golf", 14900, 102000, 2018, "Stuttgart", "Tempomat, PDC", "Wartung vollständig dokumentiert, Rechnungen vorhanden."),
    ("Volkswagen", "Passat Variant", 16400, 145000, 2017, "Freiburg", "Navi, Anhängerkupplung", "Unfallschaden vorne; Reparaturstatus unbekannt."),
    ("Volkswagen", "Polo", 10900, 76000, 2019, "Tübingen", "Klima, Bluetooth", "Keine Angabe zur Anzahl der Vorbesitzer oder zum Service."),
    ("Volkswagen", "Tiguan", 21900, 112000, 2019, "Heilbronn", "Allrad, Kamera", "Kupplung rutscht bei stärkerer Beschleunigung."),
    ("Volkswagen", "Touran", 12400, 165000, 2016, "Aalen", "Sieben Sitze, PDC", "Tacho 165000 km, Beschreibung behauptet 65000 km: Widerspruch."),
    ("Opel", "Astra", 8900, 114000, 2017, "Esslingen", "Klima, Tempomat", "Regelmäßige Wartung laut Rechnungen, vollständig belegt."),
    ("Opel", "Corsa", 7900, 89000, 2018, "Ulm", "Bluetooth, Klima", "Leichte Kratzer; Angaben zur Unfallhistorie fehlen."),
    ("Ford", "Focus", 11500, 105000, 2018, "Reutlingen", "Navi, PDC", "Zahnriemenwechsel nicht nachgewiesen, Historie unklar."),
    ("Ford", "Fiesta", 8400, 97000, 2017, "Ludwigsburg", "Klima, Sitzheizung", "Motor läuft im Leerlauf unruhig und Kontrollleuchte brennt."),
    ("Toyota", "Corolla", 18900, 64000, 2020, "Stuttgart", "Hybrid, Kamera", "Wartungshistorie vollständig, Hybridcheck dokumentiert."),
    ("Toyota", "Yaris", 11900, 71000, 2019, "Böblingen", "Klima, Kamera", "Seitenschaden nach Unfall angegeben, keine Fotos der Reparatur."),
    ("Skoda", "Octavia", 15400, 128000, 2018, "Karlsruhe", "Navi, Tempomat", "Scheckheft fehlt; Kilometerstand nicht unabhängig belegt."),
    ("Hyundai", "i30", 12800, 83000, 2019, "Ulm", "Klimaautomatik, Kamera", "Servicebelege vorhanden; genaue Anzahl der Halter fehlt."),
    ("Seat", "Leon", 14200, 96000, 2018, "Freiburg", "LED, Navi", "Unfallfrei laut Titel, reparierter Frontschaden im Text: Widerspruch."),
    ("Renault", "Clio", 6900, 120000, 2016, "Pforzheim", "Klima, Radio", "Preis auffällig günstig; technische Angaben und HU-Termin fehlen."),
]


def create_database(db_path=DATABASE):
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    # Exklusives Anlegen verhindert ein versehentliches Überschreiben.
    with db_path.open("xb"):
        pass
    try:
        with closing(sqlite3.connect(db_path)) as db:
            db.execute("PRAGMA foreign_keys = ON")
            for migration in ("001-initial.sql", "002-synthetic-vehicles.sql", "003-analysis-status.sql", "004-orders.sql"):
                db.executescript((ROOT / "memory" / "migrations" / migration).read_text(encoding="utf-8"))
            for number, (brand, model, price, km, year, location, equipment, description) in enumerate(VEHICLES, 1):
                listing_id = f"SYN-{number:03d}"
                db.execute("INSERT INTO listings VALUES (?, ?, ?, ?)",
                           (listing_id, "synthetische Testdaten; keine externe Quelle", description, "2026-01-01T00:00:00Z"))
                db.execute("INSERT INTO synthetic_vehicles VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)",
                           (listing_id, brand, model, price, km, year, location, equipment))
            db.commit()
    except Exception:
        db_path.unlink(missing_ok=True)
        raise
    print(f"Erstellt: {db_path} ({len(VEHICLES)} synthetische Fahrzeuge)")


if __name__ == "__main__":
    create_database()
