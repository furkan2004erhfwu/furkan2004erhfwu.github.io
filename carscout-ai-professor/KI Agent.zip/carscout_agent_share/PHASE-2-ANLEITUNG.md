# CarScout AI – Phase 2

Hinweis: Dieses Dokument beschreibt den damaligen Phase-2-Stand. Der aktuelle
Stand und die geänderten Sicherheitsregeln stehen in `PHASE-3A-ANLEITUNG.md`.

Alle 30 Anzeigen sind frei erfundene Testdaten. Es gibt keine echten Quellen,
Verkäufer, Scraper, Kontaktaufnahme oder API-Aufrufe. Die Suche liest nur die
lokale SQLite-Datei. Eine automatische Risikoanalyse gibt es noch nicht.

## Dateien

- `memory/carscout-test.sqlite3`: lokale Datenbank mit den 30 Testanzeigen.
- `memory/migrations/002-synthetic-vehicles.sql`: ergänzt die ursprünglichen
  Tabellen um Fahrzeugdaten und eine verpflichtende Kennzeichnung als Testdaten.
- `create_test_database.py`: erstellt die Datenbank aus den enthaltenen
  fiktiven Beispielen. Eine vorhandene Datenbank wird nicht überschrieben.
- `vehicles.py`: enthält die Suchfunktion und ein ausführbares Suchbeispiel.
- `test_vehicles.py`: prüft Anzahl, IDs, Suchergebnisse und Risikobeispiele.
- `validate_contracts.py` und `requirements-validation.txt`: zusätzliche
  Prüfung von YAML und JSON-Schema mit separat installierbaren Prüfpaketen.

## So prüfen Sie die Ergebnisse

Öffnen Sie ein Terminal im Ordner `carscout-ai`. Mit installiertem Python 3
führen Sie aus:

```powershell
python vehicles.py
python -m unittest -v test_vehicles
```

Der erste Befehl zeigt synthetische BMW bis 20.000 Euro und bis 150.000 km.
Der zweite führt acht Tests mit eigens erstellten temporären Datenbanken aus;
`OK` bedeutet, dass alle Tests bestanden sind. Die Tests prüfen konkrete
Freitexte, führen aber keine Risikoanalyse durch. Die bestehende Datenbank wird
dabei nicht verändert.
Falls Windows `python` nicht findet, installieren Sie Python 3 und verwenden Sie
gegebenenfalls `py` statt `python`.

Für eigene Suchanfragen starten Sie `python` im Projektordner und geben ein:

```python
from vehicles import search_vehicles
search_vehicles(brand="Audi", max_price=20000, max_mileage=120000)
```

Alle drei Filter sind optional. Preis und Kilometerstand sind Obergrenzen und
schließen den angegebenen Wert ein. Die Marke muss vollständig stimmen;
Groß-/Kleinschreibung spielt bei den hier verwendeten Markennamen keine Rolle.
Mit `exit()` verlassen Sie die Python-Eingabe.

Wenn die Datenbank fehlt, kann sie mit `python create_test_database.py` neu
erstellt werden. Der Befehl verweigert das Überschreiben einer vorhandenen Datei.

## Technische Restprüfung und offene Architekturfragen

Die JSON-Dateien wurden als JSON eingelesen, beide SQL-Migrationen mit SQLite
ausgeführt und die Fremdschlüssel geprüft. YAML und JSON-Schema konnten hier
noch nicht mit den benötigten Bibliotheken geprüft werden: Sie waren nicht
installiert und ein Installationsversuch lieferte keine verfügbaren Pakete.
Auf einem Rechner mit Python und Zugang zu den Paketen lässt sich dies im
Projektordner nachholen:

```powershell
python -m pip install -r requirements-validation.txt
python validate_contracts.py
```

PyYAML prüft dabei die YAML-Syntax; `jsonschema` prüft das Schema gegen das
angegebene Draft-2020-12-Metaschema. Eine erfolgreiche Prüfung bestätigt keine
Trinity-Konformität. Suche und Fahrzeugtests benötigen diese Pakete nicht.

Die referenzierte Trinity-Seite war beim Zugriff nicht erreichbar. Daher lässt
sich nicht bestätigen, ob Struktur und Inhalte der sechs Vertragsdateien den
Vorgaben entsprechen. Die Dateien sind weiterhin als projektspezifische Entwürfe
gekennzeichnet. `workflow.json` ist eine Beschreibung, keine ausführbare Engine;
Freigaberegeln sind Verträge und noch keine technisch durchgesetzten Sperren.
Die lokale Testdatenbank und Migration 002 sind eigene Phase-2-Ergänzungen,
keine als Trinity-Standard bestätigten Vorgaben.

## Änderungen an den Vertragsdateien

- `manifest.json` und `role.yaml`: Status auf Phase 2 mit lokalen Testdaten
  aktualisiert, weil eine Datenbank und Suche vorhanden sind.
- `workflow.json`: Status beschreibt nun den weiterhin nur geplanten Workflow,
  ohne den Stand des gesamten Projekts fälschlich auf Phase 1 zu setzen.
- `AGENTS.md`: Projektstand ergänzt; eine Risikoanalyse ist noch nicht umgesetzt.

Die übrigen beiden Phase-1-Vertragsdateien blieben unverändert. Die Änderungen
bestätigen keine Übereinstimmung mit der bislang nicht verfügbaren Vorlage.
