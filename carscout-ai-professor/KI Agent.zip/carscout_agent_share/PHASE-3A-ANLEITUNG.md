# CarScout AI – Phase 3A

Dies ist ein experimenteller Agent für ausschließlich synthetische Testdaten.
Er ist nicht für echte Einkaufsentscheidungen geeignet. Die LLM-Risikoanalyse
ist fehlbar und muss von Menschen geprüft werden. Es gibt keine Scraper, keinen
Kontakt und keinen Kauf. Vor späteren externen Aktionen wäre jeweils eine
ausdrückliche menschliche Freigabe nötig; solche Aktionen sind nicht implementiert.

## Neue Dateien

- `agent.py`: Terminal-Demo, OpenAI Responses API und begrenzte Werkzeugschleife.
- `agent_tools.py`: validierte lokale Suche, Details, Margenberechnung und Speichern.
- `test_agent.py`: Tests mit simulierten Modellantworten, ohne Netzwerk und Schlüssel.
- `test_safety.py`: zusätzliche Sicherheits-, Grenzfall- und Schematests.
- `test_status.py`: prüft Rückfragen, gespeicherte Status und die Migration.
- `orders.py`, `test_orders.py`: gespeicherte Aufträge und Fortsetzungstests.
- `memory/migrations/003-analysis-status.sql`: ergänzt den Auftragsstatus.
- `memory/migrations/004-orders.sql`: Aufträge und Analysezuordnung.
- `schema_check.py`: begrenzter Prüfer für die im Vertrag verwendeten Schema-Regeln.
- `offline_demo.py`: fest geskriptete kostenlose Demonstration ohne echtes LLM.
- `requirements-agent.txt`: benötigtes offizielles OpenAI-Python-Paket.
- `.env.example`: Vorlage für Variablennamen, ohne echten Schlüssel; wird nicht geladen.
- `TRINITY-ABGLEICH.md`: getrennter Stand zum offenen Architekturabgleich.

Die Datenbank und die vorhandene Suchfunktion bleiben bestehen. Gespeicherte
Analysen landen zusätzlich in der vorhandenen Tabelle `analyses` derselben
lokalen Datenbank; ursprüngliche Inserate bleiben unverändert. Die Ausgabe
folgt dem Entwurf `output.schema.json`, die inhaltliche Qualität ist nicht
garantiert. Fakten aus Inseraten sind Verkäuferangaben, keine unabhängig
bestätigten Tatsachen. Das Modell erhält die Anweisung, Inserattexte als Daten
und nicht als Anweisungen zu behandeln; dies allein ist kein vollständiger Schutz.

## Kostenlos offline testen

Im Projektordner mit Python 3 ausführen:

```powershell
python -m unittest -v
python offline_demo.py
```

Die Tests simulieren die Modellantworten. Sie prüfen den Ablauf und konkrete
Risikohinweise; sie beweisen nicht, dass ein echtes Modell alle Risiken erkennt.
Es wird keine API aufgerufen und kein API-Schlüssel benötigt. Die Tests verwenden
temporäre Datenbanken und verändern die vorhandene Datenbank nicht.
Die Offline-Demo zeigt einen fest vorgegebenen simulierten Modellablauf. Sie
versteht keine freien Suchaufträge und prüft keine echte Modellintelligenz.
Bei der letzten lokalen Prüfung bestanden 38 Offline-Tests; auch die Demo lief.
Die Tests decken unter anderem mehrfache Rückfragen, Abbruch, Status nach
Unterbrechung, spätere Margeneingaben und die Migration älterer Daten ab.

## Später mit OpenAI starten

1. Python 3 installieren und im Terminal den Projektordner öffnen.
2. Die Bibliothek installieren: `python -m pip install -r requirements-agent.txt`.
3. Einen eigenen OpenAI-API-Schlüssel einrichten. Den Schlüssel vertraulich
   behandeln und niemals im Chat, Projekt, ZIP oder in `.env.example` speichern.
4. In PowerShell für das aktuelle Terminal setzen:

   ```powershell
   $env:OPENAI_API_KEY = 'HIER_EIGENEN_SCHLUESSEL_EINSETZEN'
   $env:OPENAI_MODEL = 'HIER_EIN_VERFUEGBARES_MODELL_EINTRAGEN'
   python agent.py
   ```

   Die Zeile mit dem Schlüssel selbst lokal eingeben und nicht weiterleiten.
   Modellzugang und Kosten hängen vom eigenen OpenAI-Konto ab. Die `.env.example`
   wird absichtlich nicht automatisch geladen; nur echte Umgebungsvariablen zählen.
5. Auftrag eingeben, z. B. `Suche einen BMW bis 18000 Euro und prüfe Risiken`.
   Für eine optionale Margenberechnung eine Fahrzeug-ID angeben und anschließend
   Einkaufspreis, Nebenkosten, Aufbereitung und angenommenen Verkaufspreis
   separat eingeben. Unbekannte Werte durch Enter auslassen: Dann bleibt die
   Marge unbekannt. Das Modell darf diese Werte nicht ersetzen; sein Aufruf wird
   mit allen vier Eingaben und der Fahrzeug-ID verglichen. Mit Enter bei der ID
   wird ohne Margeneingaben fortgefahren. Für ein anderes Fahrzeug oder neue
   Werte die Demo mit neuen Eingaben erneut starten.
6. Erst die Bestätigung `ja` startet die möglicherweise kostenpflichtige Anfrage.
   Pro Auftrag sind standardmäßig höchstens acht Werkzeugaufrufe und zehn
   Modellantworten erlaubt. Die Grenzwerte sind keine feste Kostengarantie.

Das Modell wählt Werkzeuge, Python führt sie lokal aus und schickt Ergebnisse
zurück. Das Modell kann mehrere Schritte wählen; es speichert Analysen über
`save_analysis`. Python ergänzt Quelle, ausstehende Freigaben und ausschließlich
eine selbst berechnete Marge. Die Eingaben werden einzeln als Nutzerangaben
gekennzeichnet. Der Verkaufspreis ist eine Annahme, keine Marktbewertung.
Eingaben müssen einzeln geprüft werden; ihre Korrektheit kann das Programm nicht
nachweisen. Weitere Kosten, Steuern und Risiken werden nicht eingerechnet.

Die Anzeige trennt den direkt aus der Datenbank ausgelesenen Inseratstext von
Modellinterpretationen. Das Inserat bleibt eine nicht unabhängig bestätigte und
nicht vertrauenswürdige Angabe. Freier Abschlusstext des Modells wird weiterhin
nicht angezeigt. Das Modell kann stattdessen eine Kategorie für eine Rückfrage
wählen; das Programm zeigt dazu einen festen Fragetext mit Kennzeichnung an.
Das begrenzt die möglichen Behauptungen, deckt aber nicht jede denkbare Frage ab.
Rückfragen lassen sich im gleichen Terminalauftrag beantworten. Leere und
ungültige Antworten werden erneut angefordert; `/abbrechen` beendet den Auftrag.
Der bisherige Kontext und die Auftrags-ID bleiben erhalten. Die Grenzen gelten
für den gesamten Auftrag: standardmäßig höchstens zehn Modellantworten, acht
Werkzeugaufrufe und drei Rückfragen.
Nach erfolgreichem Abschluss zeigt das Programm eine eigene Abschlussmeldung.
Die Zustände `rueckfrage`, `keine_analyse`, `unvollstaendig`/`fehler`/`limit`
und `fertig` sind unterscheidbar. Im gespeicherten Bericht sind alle Modellformulierungen und der
Modellvorschlag ungeprüft – auch wenn sie Zahlen oder Handlungen behaupten.
Nur das von Python ergänzte Margenfeld ist ein rechnerisches Werkzeugergebnis.
Limits und Fehler kennzeichnen den Auftrag als unvollständig; bereits gespeicherte
Teilanalysen bleiben in der Datenbank erhalten und sind nicht abschließend.

## Aufträge und gespeicherte Analysen

Jeder gestartete Auftrag hat eine eindeutige ID und den Status `in_bearbeitung`,
`wartet_auf_antwort`, `abgeschlossen`, `unvollstaendig` oder `abgebrochen`.
Gespeichert werden Auftragstext, Modellname, Nachrichten- und Werkzeugverlauf,
aktuelle Frage, Zähler, separat eingegebene Margenwerte und Zwischenstände.
API-Schlüssel werden nicht gespeichert. Keine Geheimnisse oder echten
Personendaten in Aufträge und Antworten eingeben. Analysen werden über `order_id`
zugeordnet. Endstatus von Auftrag und Analysen werden transaktional gespeichert.

Den Status liest man in Python mit `Orders(DATABASE).read("HIER-AUFTRAGS-ID")`
nach `from orders import Orders` und `from vehicles import DATABASE`. Der
Terminalablauf beantwortet Rückfragen während derselben Ausführung. Ein nach
Programmende wartender Auftrag kann programmatisch über `run_agent` mit
`resume_order_id`, `answer` und demselben Datenbankpfad fortgesetzt werden;
eine Auswahl dafür beim Terminal-Neustart gibt es noch nicht. Nach einem
unerwarteten Abbruch kann `in_bearbeitung` stehen bleiben; der Auftrag ist dann
nicht automatisch abgeschlossen und wird nicht automatisch fortgesetzt.

Neue Analysen werden zunächst mit `vorlaeufig` gespeichert. Erst nach einem
erfolgreichen Ende des gesamten Auftrags erhalten sie `abgeschlossen`. Bei
Fehlern oder Limits werden sie `unvollstaendig`; während einer Rückfrage bleiben
sie `vorlaeufig`. Bricht das Programm
unerwartet ab oder kann es den Abschluss nicht speichern, bleibt `vorlaeufig`
erhalten. Dieser Status bescheinigt nur den technischen Ablauf, keine fachliche
Richtigkeit oder menschliche Freigabe.

Beim Start eines Auftrags werden fehlende Migrationen 003 und 004 innerhalb
einer Transaktion angewendet. Frühere Analysen bleiben erhalten, ihre unbekannte
Auftragszuordnung bleibt leer und ihre früheren Status werden auf `unbekannt`
gesetzt. Die Projekt-Datenbank wird durch die Tests nicht migriert oder
verändert. Ein späterer Leser kann `agent_tools.read_analysis_statuses()` nutzen:
Auch bei einer noch nicht migrierten Datenbank liefert die Funktion für ältere
Datensätze `unbekannt`, ohne die Datei zu verändern. `unbekannt` darf nicht als
abgeschlossen interpretiert werden.

Bei einer Rückfrage zu Margen müssen die vier Werte und die Fahrzeug-ID
ausdrücklich in den separaten Terminalfeldern eingegeben werden. Eine bloße
Textantwort oder Modellannahme gilt nicht als bestätigte Margeneingabe.

## Grenzen und Prüfung

Die echte API-Anbindung wurde ohne kostenpflichtigen Aufruf implementiert; ein
Live-Test mit echtem Schlüssel steht aus. Das Modell kann falsche oder
unvollständige Aussagen erzeugen, besonders bei freien Texten. Es gibt keine
aktuellen Marktdaten und keine Steuer-, Gewährleistungs- oder Gewinnkalkulation.
Es gibt keine Prüfung, ob Nutzereingaben wirtschaftlich korrekt sind. Die
Trennung von Anweisungen und Inseratstexten und die festen Werkzeuge begrenzen
die Auswirkungen manipulativer Texte, verhindern aber keine falschen
Modellinterpretationen. Die Tests simulieren Angriffe und sind kein Beweis für
vollständigen Schutz. Spätere echte Aktionen benötigen separate, technisch
durchgesetzte menschliche Freigaben; solche Aktionen gibt es hier nicht.

Vor dem Speichern werden Analysen gegen die im aktuellen `output.schema.json`
verwendeten Regeln geprüft. `schema_check.py` unterstützt dafür eine begrenzte
Teilmenge und lehnt unbekannte Schemaschlüssel ab. Die Prüfung kontrolliert
Form und Datentypen, nicht die Wahrheit der Aussagen. Leere Fakten-, Risiko-
oder Unsicherheitslisten sowie sehr kurze Texte werden zusätzlich abgewiesen;
auch das garantiert keine inhaltlich vollständige Analyse. Die unabhängige
Prüfung des Schemas gegen das Metaschema ist separat und noch offen.

YAML- und JSON-Schema-Prüfungen: siehe `PHASE-2-ANLEITUNG.md`; Stand und
Architekturabgleich separat in `TRINITY-ABGLEICH.md`.
