"""Prüft Instanzen gegen die im Projektvertrag verwendete JSON-Schema-Teilmenge.

Kein allgemeiner JSON-Schema-Validator: unbekannte Prüf-Schlüssel führen zum
Fehler. Eine Prüfung des Metaschemas benötigt weiterhin jsonschema.
"""
from datetime import datetime
import json
import math
from pathlib import Path
import re

SCHEMA_FILE = Path(__file__).resolve().parent / "output.schema.json"
ANNOTATIONS = {"$schema", "$id", "title", "description"}
SUPPORTED = ANNOTATIONS | {"type", "properties", "required", "additionalProperties", "items", "minLength", "minProperties", "pattern", "enum", "oneOf", "format"}


def validate(value, schema, path="$", depth=0):
    if depth > 30 or not isinstance(schema, dict):
        raise ValueError(f"Ungültiges oder zu tiefes Schema: {path}")
    unknown = set(schema) - SUPPORTED
    if unknown:
        raise ValueError(f"Nicht unterstützte Schema-Vorgaben: {sorted(unknown)}")
    if "oneOf" in schema:
        matches = 0
        for option in schema["oneOf"]:
            try:
                validate(value, option, path, depth + 1)
                matches += 1
            except ValueError:
                pass
        if matches != 1:
            raise ValueError(f"{path}: oneOf nicht erfüllt")
    types = schema.get("type")
    if types is not None:
        types = [types] if isinstance(types, str) else types
        checks = {"null": value is None, "object": isinstance(value, dict),
                  "array": isinstance(value, list), "string": isinstance(value, str),
                  "number": isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value),
                  "integer": isinstance(value, int) and not isinstance(value, bool)}
        if not types or any(t not in checks for t in types) or not any(checks[t] for t in types):
            raise ValueError(f"{path}: ungültiger Typ")
    if "enum" in schema and value not in schema["enum"]:
        raise ValueError(f"{path}: ungültiger Wert")
    if isinstance(value, str):
        if len(value) < schema.get("minLength", 0) or ("pattern" in schema and not re.search(schema["pattern"], value)):
            raise ValueError(f"{path}: ungültiger Text")
        if schema.get("format") == "date-time":
            try:
                parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
                if parsed.tzinfo is None:
                    raise ValueError
            except ValueError:
                raise ValueError(f"{path}: Datum mit Zeitzone erforderlich")
        elif "format" in schema:
            raise ValueError(f"Nicht unterstütztes Format: {schema['format']}")
    if isinstance(value, dict):
        if len(value) < schema.get("minProperties", 0) or not set(schema.get("required", [])) <= set(value):
            raise ValueError(f"{path}: Pflichtfelder fehlen")
        properties = schema.get("properties", {})
        for key, item in value.items():
            sub = properties.get(key, schema.get("additionalProperties", True))
            if sub is False:
                raise ValueError(f"{path}.{key}: zusätzliches Feld unzulässig")
            if isinstance(sub, dict):
                validate(item, sub, f"{path}.{key}", depth + 1)
    if isinstance(value, list) and "items" in schema:
        for index, item in enumerate(value):
            validate(item, schema["items"], f"{path}[{index}]", depth + 1)


def validate_analysis(analysis):
    schema = json.loads(SCHEMA_FILE.read_text(encoding="utf-8"))
    if schema.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
        raise ValueError("Unbekannte Schema-Version")
    def check_nodes(node):
        if not isinstance(node, dict) or set(node) - SUPPORTED:
            raise ValueError("Schema enthält nicht unterstützte Vorgaben")
        for child in node.get("properties", {}).values():
            check_nodes(child)
        for child in node.get("oneOf", []):
            check_nodes(child)
        for name in ("items", "additionalProperties"):
            if isinstance(node.get(name), dict):
                check_nodes(node[name])
    check_nodes(schema)
    validate(analysis, schema)
