"""Wertet gespeicherte Werkzeugspuren aus; keine Modell- oder Netzwerkaufrufe."""
import json
from orders import Orders


def report_order(db_path, order_id, case):
    order = Orders(db_path).read(order_id)
    events, pending = [], {}
    for item in order['context']['conversation']:
        if item.get('type') == 'function_call':
            event = {'tool': item.get('name'), 'completed': False}
            try:
                args = json.loads(item.get('arguments', '{}'))
                if isinstance(args, dict):
                    # Nur die für die Prüfung benötigten, synthetischen Angaben speichern.
                    for key in ('listing_id', 'category', 'brand', 'max_price', 'max_mileage'):
                        value = args.get(key)
                        if isinstance(value, (int, float)) and not isinstance(value, bool):
                            event[key] = value
                        elif isinstance(value, str) and len(value) <= 100:
                            event[key] = value
            except (ValueError, TypeError):
                event['arguments_invalid'] = True
            events.append(event)
            pending[item.get('call_id')] = event
        elif item.get('type') == 'function_call_output' and item.get('call_id') in pending:
            event = pending[item['call_id']]
            event['completed'] = True
            try:
                result = json.loads(item['output'])
                event['error'] = 'error' in result
                if event['tool'] == 'search_vehicles':
                    event['vehicle_ids'] = [v.get('id') for v in result.get('vehicles', [])]
                if event['tool'] == 'calculate_margin':
                    event['python_margin'] = result.get('margin')
                if event['tool'] == 'save_analysis':
                    event['saved'] = result.get('saved', False)
            except (ValueError, TypeError, KeyError):
                event['output_invalid'] = True
    analyses = order['context'].get('saved', [])
    names = [e['tool'] for e in events if e['completed'] and not e.get('error')]
    checks = {
        'suche_verwendet': 'search_vehicles' in names,
        'analyse_gespeichert': 'save_analysis' in names,
        'ziel_fahrzeug_untersucht': any(e['tool'] == 'get_vehicle_details' and e.get('listing_id') == case['target_id'] and e['completed'] and not e.get('error') for e in events),
        'rueckfrage_gestellt': 'ask_clarification' in names,
    }
    if case['id'] == 'risiko':
        checks['python_marge_2300_eur'] = any(e.get('python_margin') and e['python_margin'].get('amount') == 2300 for e in events)
    # Diese Schlüsselwortprüfung ersetzt keine menschliche inhaltliche Bewertung.
    if case['id'] == 'risiko':
        content = ' '.join(str(a.get('analysis', {})) for a in analyses).lower()
        checks['risikohinweis_automatisch_erkennbar'] = any(term in content for term in ('motorwarn', 'warnleuchte', 'leistungsverlust'))
    return {'case_id': case['id'], 'order_id': order_id, 'order_status': order['status'],
            'tool_events': events, 'checks': checks,
            'manual_review': 'Modellinterpretationen, offene Fragen und alle Annahmen in der Terminalausgabe selbst prüfen; Treffer ist kein Qualitätsnachweis.'}
